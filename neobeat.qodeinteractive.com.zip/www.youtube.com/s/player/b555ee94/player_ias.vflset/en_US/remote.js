(function(g) {
    var window = this;
    'use strict';
    var rQa = function(a, b) {
            return g.Rb(a, b)
        },
        sQa = function(a, b) {
            b = b instanceof g.Ic ? b : g.Oc(b, /^data:image\//i.test(b));
            a.src = g.Jc(b)
        },
        tQa = function(a) {
            if (a instanceof g.Uh) return a;
            if ("function" == typeof a.Jg) return a.Jg(!1);
            if (g.La(a)) {
                var b = 0,
                    c = new g.Uh;
                c.i = function() {
                    for (;;) {
                        if (b >= a.length) throw g.$h;
                        if (b in a) return a[b++];
                        b++
                    }
                };
                c.next = c.i.bind(c);
                return c
            }
            throw Error("Not implemented");
        },
        uQa = function(a, b, c) {
            if (g.La(a)) try {
                g.Eb(a, b, c)
            } catch (d) {
                if (d !== g.$h) throw d;
            } else {
                a = tQa(a);
                try {
                    for (;;) b.call(c, a.i(), void 0, a)
                } catch (d) {
                    if (d !== g.$h) throw d;
                }
            }
        },
        N6 = function(a) {
            g.sk(a, "zx", Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ g.Sa()).toString(36));
            return a
        },
        O6 = function(a, b, c) {
            Array.isArray(c) || (c = [String(c)]);
            g.xk(a.l, b, c)
        },
        vQa = function(a, b) {
            var c = [];
            uQa(b, function(d) {
                try {
                    var e = g.nr.prototype.l.call(this, d, !0)
                } catch (f) {
                    if ("Storage: Invalid value was encountered" == f) return;
                    throw f;
                }
                void 0 === e ? c.push(d) : g.mr(e) && c.push(d)
            }, a);
            return c
        },
        wQa = function(a, b) {
            vQa(a, b).forEach(function(c) {
                g.nr.prototype.remove.call(this, c)
            }, a)
        },
        xQa = function(a) {
            if (a.U) {
                if (a.U.locationOverrideToken) return {
                    locationOverrideToken: a.U.locationOverrideToken
                };
                if (null != a.U.latitudeE7 && null != a.U.longitudeE7) return {
                    latitudeE7: a.U.latitudeE7,
                    longitudeE7: a.U.longitudeE7
                }
            }
            return null
        },
        yQa = function(a, b) {
            g.kb(a, b) || a.push(b)
        },
        P6 = function(a) {
            var b = 0,
                c;
            for (c in a) b++;
            return b
        },
        zQa = function(a) {
            try {
                return g.C.JSON.parse(a)
            } catch (b) {}
            a = String(a);
            if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + a + ")")
            } catch (b) {}
            throw Error("Invalid JSON string: " + a);
        },
        Q6 = function(a) {
            if (g.C.JSON) try {
                return g.C.JSON.parse(a)
            } catch (b) {}
            return zQa(a)
        },
        AQa = function(a, b, c, d) {
            var e = new g.fk(null, void 0);
            a && g.gk(e, a);
            b && g.hk(e, b);
            c && g.ik(e, c);
            d && (e.J = d);
            return e
        },
        R6 = function(a, b) {
            g.Uu[a] = !0;
            var c = g.Su();
            c && c.publish.apply(c, arguments);
            g.Uu[a] = !1
        },
        S6 = function(a) {
            this.name = this.id = "";
            this.clientName = "UNKNOWN_INTERFACE";
            this.app = "";
            this.type = "REMOTE_CONTROL";
            this.obfuscatedGaiaId = this.avatar = this.username = "";
            this.capabilities = new Set;
            this.experiments = new Set;
            this.theme = "u";
            new g.bi;
            this.model = this.brand = "";
            this.year = 0;
            this.chipset = this.osVersion = this.os = "";
            this.mdxDialServerType = "MDX_DIAL_SERVER_TYPE_UNKNOWN";
            a && (this.id = a.id || a.name, this.name = a.name, this.clientName = a.clientName ? a.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.app = a.app, this.type = a.type || "REMOTE_CONTROL", this.username =
                a.user || "", this.avatar = a.userAvatarUri || "", this.obfuscatedGaiaId = a.obfuscatedGaiaId || "", this.theme = a.theme || "u", BQa(this, a.capabilities || ""), CQa(this, a.experiments || ""), this.brand = a.brand || "", this.model = a.model || "", this.year = a.year || 0, this.os = a.os || "", this.osVersion = a.osVersion || "", this.chipset = a.chipset || "", this.mdxDialServerType = a.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN", a = a.deviceInfo) && (a = JSON.parse(a), this.brand = a.brand || "", this.model = a.model || "", this.year = a.year || 0, this.os = a.os || "",
                this.osVersion = a.osVersion || "", this.chipset = a.chipset || "", this.clientName = a.clientName ? a.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.mdxDialServerType = a.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN")
        },
        BQa = function(a, b) {
            a.capabilities.clear();
            g.Jo(b.split(","), g.Ra(rQa, DQa)).forEach(function(c) {
                a.capabilities.add(c)
            })
        },
        CQa = function(a, b) {
            a.experiments.clear();
            b.split(",").forEach(function(c) {
                a.experiments.add(c)
            })
        },
        T6 = function(a) {
            a = a || {};
            this.name = a.name || "";
            this.id = a.id || a.screenId || "";
            this.token = a.token || a.loungeToken || "";
            this.uuid = a.uuid || a.dialId || "";
            this.idType = a.screenIdType || "normal"
        },
        U6 = function(a, b) {
            return !!b && (a.id == b || a.uuid == b)
        },
        EQa = function(a) {
            return {
                name: a.name,
                screenId: a.id,
                loungeToken: a.token,
                dialId: a.uuid,
                screenIdType: a.idType
            }
        },
        FQa = function(a) {
            return new T6(a)
        },
        GQa = function(a) {
            return Array.isArray(a) ? g.Qe(a, FQa) : []
        },
        V6 = function(a) {
            return a ? '{name:"' + a.name + '",id:' + a.id.substr(0, 6) + "..,token:" + ((a.token ? ".." + a.token.slice(-6) : "-") + ",uuid:" + (a.uuid ? ".." + a.uuid.slice(-6) : "-") + ",idType:" + a.idType + "}") : "null"
        },
        W6 = function(a) {
            return Array.isArray(a) ? "[" + g.Qe(a, V6).join(",") + "]" : "null"
        },
        X6 = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
                function(a) {
                    var b = 16 * Math.random() | 0;
                    return ("x" == a ? b : b & 3 | 8).toString(16)
                })
        },
        HQa = function(a) {
            return g.Qe(a, function(b) {
                return {
                    key: b.id,
                    name: b.name
                }
            })
        },
        Y6 = function(a, b) {
            return g.gb(a, function(c) {
                return c || b ? !c != !b ? !1 : c.id == b.id : !0
            })
        },
        Z6 = function(a, b) {
            return g.gb(a, function(c) {
                return U6(c, b)
            })
        },
        IQa = function() {
            var a = (0, g.wz)();
            a && wQa(a, a.i.Jg(!0))
        },
        $6 = function() {
            var a = g.zz("yt-remote-connected-devices") || [];
            g.Ab(a);
            return a
        },
        JQa = function(a) {
            if (g.lb(a)) return [];
            var b = a[0].indexOf("#"),
                c = -1 == b ? a[0] : a[0].substring(0, b);
            return g.Qe(a, function(d, e) {
                return 0 == e ? d : d.substring(c.length)
            })
        },
        KQa = function(a) {
            g.yz("yt-remote-connected-devices", a, 86400)
        },
        b7 = function() {
            if (a7) return a7;
            var a = g.zz("yt-remote-device-id");
            a || (a = X6(), g.yz("yt-remote-device-id", a, 31536E3));
            for (var b = $6(), c = 1, d = a; g.kb(b, d);) c++, d = a + "#" + c;
            return a7 = d
        },
        c7 = function() {
            var a = $6(),
                b = b7();
            g.kb(a, b);
            g.Cz() && g.Db(a, b);
            a = JQa(a);
            if (g.lb(a)) try {
                g.Dt("remote_sid")
            } catch (c) {} else try {
                g.Bt("remote_sid", a.join(","), -1)
            } catch (c) {}
        },
        LQa = function() {
            return g.zz("yt-remote-session-browser-channel")
        },
        MQa = function() {
            return g.zz("yt-remote-local-screens") || []
        },
        NQa = function() {
            g.yz("yt-remote-lounge-token-expiration", !0, 86400)
        },
        OQa = function(a) {
            5 < a.length && (a = a.slice(a.length - 5));
            var b = g.Qe(MQa(), function(d) {
                    return d.loungeToken
                }),
                c = g.Qe(a, function(d) {
                    return d.loungeToken
                });
            g.Am(c, function(d) {
                return !g.kb(b, d)
            }) && NQa();
            g.yz("yt-remote-local-screens", a, 31536E3)
        },
        PQa = function(a, b) {
            g.yz("yt-remote-session-browser-channel", a);
            g.yz("yt-remote-session-screen-id", b);
            a = $6();
            b = b7();
            g.kb(a, b) || a.push(b);
            KQa(a);
            c7()
        },
        d7 = function(a) {
            a || (g.Bz("yt-remote-session-screen-id"), g.Bz("yt-remote-session-video-id"));
            c7();
            a = $6();
            g.pb(a, b7());
            KQa(a)
        },
        QQa = function() {
            if (!e7) {
                var a = g.xr();
                a && (e7 = new g.hr(a))
            }
        },
        RQa = function() {
            QQa();
            return e7 ? !!e7.get("yt-remote-use-staging-server") : !1
        },
        f7 = function() {
            var a = window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
            return a ? parseInt(a[1], 10) : 0
        },
        SQa = function(a) {
            return !!document.currentScript && (-1 != document.currentScript.src.indexOf("?" + a) || -1 != document.currentScript.src.indexOf("&" + a))
        },
        TQa = function() {
            return "function" == typeof window.__onGCastApiAvailable ? window.__onGCastApiAvailable : null
        },
        g7 = function(a) {
            a.length ? UQa(a.shift(), function() {
                g7(a)
            }) : h7()
        },
        VQa = function(a) {
            return "chrome-extension://" + a + "/cast_sender.js"
        },
        UQa = function(a, b, c) {
            var d = document.createElement("script");
            d.onerror = b;
            c && (d.onload = c);
            g.Ej(d, g.Wq(a));
            (document.head || document.documentElement).appendChild(d)
        },
        WQa = function() {
            var a = f7(),
                b = [];
            if (1 < a) {
                var c = a - 1;
                b.push("//www.gstatic.com/eureka/clank/" + a + "/cast_sender.js");
                b.push("//www.gstatic.com/eureka/clank/" + c + "/cast_sender.js")
            }
            return b
        },
        h7 = function() {
            var a = TQa();
            a && a(!1, "No cast extension found")
        },
        i7 = function() {
            if (XQa) {
                var a = 2,
                    b = TQa(),
                    c = function() {
                        a--;
                        0 == a && b && b(!0)
                    };
                window.__onGCastApiAvailable = c;
                UQa("//www.gstatic.com/cast/sdk/libs/sender/1.0/cast_framework.js", h7, c)
            }
        },
        YQa = function() {
            i7();
            var a = WQa();
            a.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            g7(a)
        },
        $Qa = function() {
            i7();
            var a = WQa();
            a.push.apply(a, g.v(ZQa.map(VQa)));
            a.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            g7(a)
        },
        j7 = function(a, b, c) {
            g.G.call(this);
            this.I = null != c ? (0, g.D)(a, c) : a;
            this.Nf = b;
            this.C = (0, g.D)(this.LO, this);
            this.i = !1;
            this.l = 0;
            this.u = this.Ib = null;
            this.B = []
        },
        k7 = function(a, b, c) {
            g.G.call(this);
            this.B = null != c ? a.bind(c) : a;
            this.Nf = b;
            this.u = null;
            this.i = !1;
            this.l = 0;
            this.Ib = null
        },
        l7 = function(a) {
            a.Ib = g.jh(function() {
                a.Ib = null;
                a.i && !a.l && (a.i = !1, l7(a))
            }, a.Nf);
            var b = a.u;
            a.u = null;
            a.B.apply(null, b)
        },
        m7 = function() {},
        n7 = function(a, b) {
            if ("function" !== typeof a) throw Error("Fn must not be null and must be a function");
            return g.C.setTimeout(function() {
                a()
            }, b)
        },
        p7 = function(a) {
            o7.dispatchEvent(new aRa(o7, a))
        },
        aRa = function(a, b) {
            g.kf.call(this, "statevent", a);
            this.stat = b
        },
        q7 = function(a, b, c, d) {
            this.i = a;
            this.l = b;
            this.L = c;
            this.J = d || 1;
            this.u = 45E3;
            this.B = new g.yk(this);
            this.I = new g.ih;
            this.I.setInterval(250)
        },
        cRa = function(a, b, c) {
            a.Ps = 1;
            a.Fm = N6(b.clone());
            a.Xp = c;
            a.C = !0;
            bRa(a, null)
        },
        r7 = function(a, b, c, d, e) {
            a.Ps = 1;
            a.Fm = N6(b.clone());
            a.Xp = null;
            a.C = c;
            e && (a.TL = !1);
            bRa(a, d)
        },
        bRa = function(a, b) {
            a.Es = Date.now();
            s7(a);
            a.Vn = a.Fm.clone();
            O6(a.Vn, "t", a.J);
            a.rA = 0;
            a.If = a.i.hC(a.i.qw() ? b : null);
            0 < a.cB && (a.Cz = new k7((0, g.D)(a.UM, a, a.If), a.cB));
            a.B.Ra(a.If, "readystatechange", a.MO);
            b = a.Co ? g.Zb(a.Co) : {};
            a.Xp ? (a.nA = "POST", b["Content-Type"] = "application/x-www-form-urlencoded", a.If.send(a.Vn, a.nA, a.Xp, b)) : (a.nA = "GET", a.TL && !g.lg && (b.Connection = "close"), a.If.send(a.Vn, a.nA, null, b));
            a.i.qj(1)
        },
        eRa = function(a, b) {
            var c = a.rA,
                d = b.indexOf("\n", c);
            if (-1 == d) return t7;
            c = Number(b.substring(c, d));
            if (isNaN(c)) return dRa;
            d += 1;
            if (d + c > b.length) return t7;
            b = b.substr(d, c);
            a.rA = d + c;
            return b
        },
        gRa = function(a, b) {
            a.Es = Date.now();
            s7(a);
            var c = b ? window.location.hostname : "";
            a.Vn = a.Fm.clone();
            g.sk(a.Vn, "DOMAIN", c);
            g.sk(a.Vn, "t", a.J);
            try {
                a.Gj = new ActiveXObject("htmlfile")
            } catch (m) {
                u7(a);
                a.Bm = 7;
                p7(22);
                v7(a);
                return
            }
            var d = "<html><body>";
            if (b) {
                var e = "";
                for (b = 0; b < c.length; b++) {
                    var f = c.charAt(b);
                    if ("<" == f) f = e + "\\x3c";
                    else if (">" == f) f = e + "\\x3e";
                    else {
                        if (f in w7) f = w7[f];
                        else if (f in fRa) f = w7[f] = fRa[f];
                        else {
                            var h = f.charCodeAt(0);
                            if (31 < h && 127 > h) var l = f;
                            else {
                                if (256 > h) {
                                    if (l = "\\x", 16 > h || 256 < h) l += "0"
                                } else l = "\\u", 4096 > h && (l += "0");
                                l += h.toString(16).toUpperCase()
                            }
                            f =
                                w7[f] = l
                        }
                        f = e + f
                    }
                    e = f
                }
                d += '<script>document.domain="' + e + '"\x3c/script>'
            }
            d += "</body></html>";
            c = g.md(g.kc("b/12014412"), d);
            a.Gj.open();
            a.Gj.write(g.gd(c));
            a.Gj.close();
            a.Gj.parentWindow.m = (0, g.D)(a.aV, a);
            a.Gj.parentWindow.d = (0, g.D)(a.lL, a, !0);
            a.Gj.parentWindow.rpcClose = (0, g.D)(a.lL, a, !1);
            c = a.Gj.createElement("DIV");
            a.Gj.parentWindow.document.body.appendChild(c);
            d = g.Nc(a.Vn.toString());
            d = g.vd(g.Jc(d));
            d = g.md(g.kc("b/12014412"), '<iframe src="' + d + '"></iframe>');
            g.od(c, d);
            a.i.qj(1)
        },
        s7 = function(a) {
            a.EF = Date.now() +
                a.u;
            hRa(a, a.u)
        },
        hRa = function(a, b) {
            if (null != a.Ws) throw Error("WatchDog timer not null");
            a.Ws = n7((0, g.D)(a.hV, a), b)
        },
        x7 = function(a) {
            a.Ws && (g.C.clearTimeout(a.Ws), a.Ws = null)
        },
        v7 = function(a) {
            a.i.jf() || a.So || a.i.Vw(a)
        },
        u7 = function(a) {
            x7(a);
            g.ef(a.Cz);
            a.Cz = null;
            a.I.stop();
            g.Ak(a.B);
            if (a.If) {
                var b = a.If;
                a.If = null;
                b.abort();
                b.dispose()
            }
            a.Gj && (a.Gj = null)
        },
        y7 = function(a, b) {
            try {
                a.i.eL(a, b), a.i.qj(4)
            } catch (c) {}
        },
        jRa = function(a, b, c, d, e) {
            if (0 == d) c(!1);
            else {
                var f = e || 0;
                d--;
                iRa(a, b, function(h) {
                    h ? c(!0) : g.C.setTimeout(function() {
                        jRa(a, b, c, d, f)
                    }, f)
                })
            }
        },
        iRa = function(a, b, c) {
            var d = new Image;
            d.onload = function() {
                try {
                    z7(d), c(!0)
                } catch (e) {}
            };
            d.onerror = function() {
                try {
                    z7(d), c(!1)
                } catch (e) {}
            };
            d.onabort = function() {
                try {
                    z7(d), c(!1)
                } catch (e) {}
            };
            d.ontimeout = function() {
                try {
                    z7(d), c(!1)
                } catch (e) {}
            };
            g.C.setTimeout(function() {
                if (d.ontimeout) d.ontimeout()
            }, b);
            sQa(d, a)
        },
        z7 = function(a) {
            a.onload = null;
            a.onerror = null;
            a.onabort = null;
            a.ontimeout = null
        },
        kRa = function(a) {
            this.i = a;
            this.l = new m7
        },
        lRa = function(a) {
            var b = A7(a.i, a.Yt, "/mail/images/cleardot.gif");
            N6(b);
            jRa(b.toString(), 5E3, (0, g.D)(a.GP, a), 3, 2E3);
            a.qj(1)
        },
        C7 = function(a) {
            var b = a.i.L;
            if (null != b) p7(5), b ? (p7(11), B7(a.i, a, !1)) : (p7(12), B7(a.i, a, !0));
            else if (a.nh = new q7(a, void 0, void 0, void 0), a.nh.Co = a.dB, b = a.i, b = A7(b, b.qw() ? a.Ht : null, a.eB), p7(5), !g.ke || g.de(10)) O6(b, "TYPE", "xmlhttp"), r7(a.nh, b, !1, a.Ht, !1);
            else {
                O6(b, "TYPE", "html");
                var c = a.nh;
                a = !!a.Ht;
                c.Ps = 3;
                c.Fm = N6(b.clone());
                gRa(c, a)
            }
        },
        D7 = function(a, b, c) {
            this.Qa = 1;
            this.i = [];
            this.u = [];
            this.B = new m7;
            this.J = a || null;
            this.L = null != b ? b : null;
            this.C = c || !1
        },
        mRa = function(a, b) {
            this.i = a;
            this.map = b;
            this.context = null
        },
        nRa = function(a, b, c, d) {
            g.kf.call(this, "timingevent", a);
            this.size = b;
            this.hw = d
        },
        oRa = function(a) {
            g.kf.call(this, "serverreachability", a)
        },
        rRa = function(a) {
            pRa(a);
            if (3 == a.Qa) {
                var b = a.Ev++,
                    c = a.Fx.clone();
                g.sk(c, "SID", a.l);
                g.sk(c, "RID", b);
                g.sk(c, "TYPE", "terminate");
                E7(a, c);
                b = new q7(a, a.l, b, void 0);
                b.Ps = 2;
                b.Fm = N6(c.clone());
                sQa(new Image, b.Fm.toString());
                b.Es = Date.now();
                s7(b)
            }
            qRa(a)
        },
        sRa = function(a) {
            a.gQ(1, 0);
            a.Fx = A7(a, null, a.fB);
            F7(a)
        },
        pRa = function(a) {
            a.Km && (a.Km.abort(), a.Km = null);
            a.Ce && (a.Ce.cancel(), a.Ce = null);
            a.rl && (g.C.clearTimeout(a.rl), a.rl = null);
            G7(a);
            a.Ug && (a.Ug.cancel(), a.Ug = null);
            a.Tm && (g.C.clearTimeout(a.Tm), a.Tm = null)
        },
        tRa = function(a, b) {
            if (0 == a.Qa) throw Error("Invalid operation: sending map when state is closed");
            a.i.push(new mRa(a.RR++, b));
            2 != a.Qa && 3 != a.Qa || F7(a)
        },
        uRa = function(a) {
            var b = 0;
            a.Ce && b++;
            a.Ug && b++;
            return b
        },
        F7 = function(a) {
            a.Ug || a.Tm || (a.Tm = n7((0, g.D)(a.jL, a), 0), a.Ar = 0)
        },
        wRa = function(a, b) {
            if (1 == a.Qa) {
                if (!b) {
                    a.Ev = Math.floor(1E5 * Math.random());
                    b = a.Ev++;
                    var c = new q7(a, "", b, void 0);
                    c.Co = a.Uj;
                    var d = H7(a),
                        e = a.Fx.clone();
                    g.sk(e, "RID", b);
                    g.sk(e, "CVER", "1");
                    E7(a, e);
                    cRa(c, e, d);
                    a.Ug = c;
                    a.Qa = 2
                }
            } else 3 == a.Qa && (b ? vRa(a, b) : 0 == a.i.length || a.Ug || vRa(a))
        },
        vRa = function(a, b) {
            if (b)
                if (6 < a.To) {
                    a.i = a.u.concat(a.i);
                    a.u.length = 0;
                    var c = a.Ev - 1;
                    b = H7(a)
                } else c = b.L, b = b.Xp;
            else c = a.Ev++, b = H7(a);
            var d = a.Fx.clone();
            g.sk(d, "SID", a.l);
            g.sk(d, "RID", c);
            g.sk(d, "AID", a.Ur);
            E7(a, d);
            c = new q7(a, a.l, c, a.Ar + 1);
            c.Co = a.Uj;
            c.setTimeout(1E4 + Math.round(1E4 * Math.random()));
            a.Ug = c;
            cRa(c, d, b)
        },
        E7 = function(a, b) {
            a.Jf && (a = a.Jf.JI()) && g.Gb(a, function(c, d) {
                g.sk(b, d, c)
            })
        },
        H7 = function(a) {
            var b = Math.min(a.i.length, 1E3),
                c = ["count=" + b];
            if (6 < a.To && 0 < b) {
                var d = a.i[0].i;
                c.push("ofs=" + d)
            } else d = 0;
            for (var e = {}, f = 0; f < b; e = {
                    Cq: e.Cq
                }, f++) {
                e.Cq = a.i[f].i;
                var h = a.i[f].map;
                e.Cq = 6 >= a.To ? f : e.Cq - d;
                try {
                    g.Gb(h, function(l) {
                        return function(m, n) {
                            c.push("req" + l.Cq + "_" + n + "=" + encodeURIComponent(m))
                        }
                    }(e))
                } catch (l) {
                    c.push("req" + e.Cq + "_type=" + encodeURIComponent("_badmap"))
                }
            }
            a.u = a.u.concat(a.i.splice(0, b));
            return c.join("&")
        },
        xRa = function(a) {
            a.Ce || a.rl || (a.I = 1, a.rl = n7((0, g.D)(a.iL, a), 0), a.Yq = 0)
        },
        I7 = function(a) {
            if (a.Ce || a.rl || 3 <= a.Yq) return !1;
            a.I++;
            a.rl = n7((0, g.D)(a.iL, a), yRa(a, a.Yq));
            a.Yq++;
            return !0
        },
        B7 = function(a, b, c) {
            a.lA = c;
            a.Vj = b.Vk;
            a.C || sRa(a)
        },
        G7 = function(a) {
            null != a.ep && (g.C.clearTimeout(a.ep), a.ep = null)
        },
        yRa = function(a, b) {
            var c = 5E3 + Math.floor(1E4 * Math.random());
            a.isActive() || (c *= 2);
            return c * b
        },
        J7 = function(a, b) {
            if (2 == b || 9 == b) {
                var c = null;
                a.Jf && (c = null);
                var d = (0, g.D)(a.dW, a);
                c || (c = new g.fk("//www.google.com/images/cleardot.gif"), N6(c));
                iRa(c.toString(), 1E4, d)
            } else p7(2);
            zRa(a, b)
        },
        zRa = function(a, b) {
            a.Qa = 0;
            a.Jf && a.Jf.XH(b);
            qRa(a);
            pRa(a)
        },
        qRa = function(a) {
            a.Qa = 0;
            a.Vj = -1;
            if (a.Jf)
                if (0 == a.u.length && 0 == a.i.length) a.Jf.UB();
                else {
                    g.sb(a.u);
                    var b = g.sb(a.i);
                    a.u.length = 0;
                    a.i.length = 0;
                    a.Jf.UB(b)
                }
        },
        A7 = function(a, b, c) {
            var d = g.tk(c);
            if ("" != d.i) b && g.hk(d, b + "." + d.i), g.ik(d, d.u);
            else {
                var e = window.location;
                d = AQa(e.protocol, b ? b + "." + e.hostname : e.hostname, +e.port, c)
            }
            a.Du && g.Gb(a.Du, function(f, h) {
                g.sk(d, h, f)
            });
            g.sk(d, "VER", a.To);
            E7(a, d);
            return d
        },
        ARa = function() {},
        BRa = function() {
            this.i = [];
            this.l = []
        },
        CRa = function(a, b) {
            this.action = a;
            this.params = b || {}
        },
        K7 = function(a, b) {
            g.G.call(this);
            this.i = new g.K(this.SU, 0, this);
            g.J(this, this.i);
            this.Nf = 5E3;
            this.l = 0;
            if ("function" === typeof a) b && (a = (0, g.D)(a, b));
            else if (a && "function" === typeof a.handleEvent) a = (0, g.D)(a.handleEvent, a);
            else throw Error("Invalid listener argument");
            this.u = a
        },
        L7 = function(a, b, c, d, e) {
            c = void 0 === c ? !1 : c;
            d = void 0 === d ? function() {
                return ""
            } : d;
            e = void 0 === e ? !1 : e;
            this.xa = a;
            this.I = b;
            this.u = new g.gr;
            this.l = new K7(this.IV, this);
            this.i = null;
            this.Z = !1;
            this.C = null;
            this.U = "";
            this.L = this.B = 0;
            this.J = [];
            this.ya = c;
            this.ea = d;
            this.Aa = e
        },
        DRa = function(a) {
            return {
                firstTestResults: [""],
                secondTestResults: !a.i.lA,
                sessionId: a.i.l,
                arrayId: a.i.Ur
            }
        },
        ERa = function(a, b) {
            a.L = b || 0;
            a.l.stop();
            M7(a);
            a.i && (3 == a.i.getState() && wRa(a.i), rRa(a.i));
            a.L = 0
        },
        N7 = function(a) {
            return !!a.i && 3 == a.i.getState()
        },
        M7 = function(a) {
            if (a.i) {
                var b = a.ea(),
                    c = a.i.Uj || {};
                b ? c["x-youtube-lounge-xsrf-token"] = b : delete c["x-youtube-lounge-xsrf-token"];
                a.i.Uj = c
            }
        },
        O7 = function(a) {
            this.port = this.domain = "";
            this.i = "/api/lounge";
            this.l = !0;
            a = a || document.location.href;
            var b = Number(g.hi(4, a)) || "";
            b && (this.port = ":" + b);
            this.domain = g.ii(a) || "";
            a = g.Yc;
            0 <= a.search("MSIE") && (a = a.match(/MSIE ([\d.]+)/)[1], 0 > g.Gc(a, "10.0") && (this.l = !1))
        },
        P7 = function(a, b) {
            var c = a.i;
            a.l && (c = "https://" + a.domain + a.port + a.i);
            return g.ti(c + b, {})
        },
        Q7 = function(a, b, c, d, e) {
            a = {
                format: "JSON",
                method: "POST",
                context: a,
                timeout: 5E3,
                withCredentials: !1,
                onSuccess: g.Ra(a.B, d, !0),
                onError: g.Ra(a.u, e),
                onTimeout: g.Ra(a.C, e)
            };
            c && (a.postParams = c, a.headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            });
            return g.ot(b, a)
        },
        IRa = function() {
            var a = FRa;
            GRa();
            R7.push(a);
            HRa()
        },
        S7 = function(a, b) {
            GRa();
            var c = JRa(a, String(b));
            g.lb(R7) ? KRa(c) : (HRa(), g.Eb(R7, function(d) {
                d(c)
            }))
        },
        GRa = function() {
            R7 || (R7 = g.Ha("yt.mdx.remote.debug.handlers_") || [], g.Ga("yt.mdx.remote.debug.handlers_", R7, void 0))
        },
        KRa = function(a) {
            var b = (T7 + 1) % 50;
            T7 = b;
            U7[b] = a;
            V7 || (V7 = 49 == b)
        },
        HRa = function() {
            var a = R7;
            if (U7[0]) {
                var b = V7 ? T7 : -1;
                do {
                    b = (b + 1) % 50;
                    var c = U7[b];
                    g.Eb(a, function(d) {
                        d(c)
                    })
                } while (b != T7);
                U7 = Array(50);
                T7 = -1;
                V7 = !1
            }
        },
        JRa = function(a, b) {
            var c = (Date.now() - LRa) / 1E3;
            c.toFixed && (c = c.toFixed(3));
            var d = [];
            d.push("[", c + "s", "] ");
            d.push("[", "yt.mdx.remote", "] ");
            d.push(a + ": " + b, "\n");
            return d.join("")
        },
        W7 = function(a) {
            g.R.call(this);
            this.I = a;
            this.screens = []
        },
        MRa = function(a, b) {
            var c = a.get(b.uuid) || a.get(b.id);
            if (c) return a = c.name, c.id = b.id || c.id, c.name = b.name, c.token = b.token, c.uuid = b.uuid || c.uuid, c.name != a;
            a.screens.push(b);
            return !0
        },
        NRa = function(a, b) {
            var c = a.screens.length != b.length;
            a.screens = g.Jo(a.screens, function(f) {
                return !!Y6(b, f)
            });
            for (var d = 0, e = b.length; d < e; d++) c = MRa(a, b[d]) || c;
            return c
        },
        ORa = function(a, b) {
            var c = a.screens.length;
            a.screens = g.Jo(a.screens, function(d) {
                return !(d || b ? !d != !b ? 0 : d.id == b.id : 1)
            });
            return a.screens.length < c
        },
        X7 = function(a, b, c, d, e) {
            g.R.call(this);
            this.u = a;
            this.J = b;
            this.B = c;
            this.I = d;
            this.C = e;
            this.l = 0;
            this.i = null;
            this.Ib = NaN
        },
        Z7 = function(a) {
            W7.call(this, "LocalScreenService");
            this.l = a;
            this.i = NaN;
            Y7(this);
            this.info("Initializing with " + W6(this.screens))
        },
        PRa = function(a) {
            if (a.screens.length) {
                var b = g.Qe(a.screens, function(d) {
                        return d.id
                    }),
                    c = P7(a.l, "/pairing/get_lounge_token_batch");
                Q7(a.l, c, {
                    screen_ids: b.join(",")
                }, (0, g.D)(a.FQ, a), (0, g.D)(a.EQ, a))
            }
        },
        Y7 = function(a) {
            if (g.ks("deprecate_pair_servlet_enabled")) return NRa(a, []);
            var b = GQa(MQa());
            b = g.Jo(b, function(c) {
                return !c.uuid
            });
            return NRa(a, b)
        },
        $7 = function(a, b) {
            OQa(g.Qe(a.screens, EQa));
            b && NQa()
        },
        b8 = function(a, b) {
            g.R.call(this);
            this.I = b;
            b = (b = g.zz("yt-remote-online-screen-ids") || "") ? b.split(",") : [];
            for (var c = {}, d = this.I(), e = 0, f = d.length; e < f; ++e) {
                var h = d[e].id;
                c[h] = g.kb(b, h)
            }
            this.i = c;
            this.C = a;
            this.u = this.B = NaN;
            this.l = null;
            a8("Initialized with " + g.Jh(this.i))
        },
        c8 = function(a, b, c) {
            var d = P7(a.C, "/pairing/get_screen_availability");
            Q7(a.C, d, {
                lounge_token: b.token
            }, (0, g.D)(function(e) {
                e = e.screens || [];
                for (var f = 0, h = e.length; f < h; ++f)
                    if (e[f].loungeToken == b.token) {
                        c("online" == e[f].status);
                        return
                    }
                c(!1)
            }, a), (0, g.D)(function() {
                c(!1)
            }, a))
        },
        d8 = function(a, b) {
            a: if (P6(b) != P6(a.i)) var c = !1;
                else {
                    c = g.Pb(b);
                    for (var d = 0, e = c.length; d < e; ++d)
                        if (!a.i[c[d]]) {
                            c = !1;
                            break a
                        }
                    c = !0
                }c || (a8("Updated online screens: " + g.Jh(a.i)), a.i = b, a.Y("screenChange"));QRa(a)
        },
        e8 = function(a) {
            isNaN(a.u) || g.jt(a.u);
            a.u = g.ht((0, g.D)(a.zE, a), 0 < a.B && a.B < g.Sa() ? 2E4 : 1E4)
        },
        a8 = function(a) {
            S7("OnlineScreenService", a)
        },
        RRa = function(a) {
            var b = {};
            g.Eb(a.I(), function(c) {
                c.token ? b[c.token] = c.id : this.Yd("Requesting availability of screen w/o lounge token.")
            });
            return b
        },
        QRa = function(a) {
            a = g.Pb(g.Ib(a.i, function(b) {
                return b
            }));
            g.Ab(a);
            a.length ? g.yz("yt-remote-online-screen-ids", a.join(","), 60) : g.Bz("yt-remote-online-screen-ids")
        },
        f8 = function(a, b) {
            b = void 0 === b ? !1 : b;
            W7.call(this, "ScreenService");
            this.B = a;
            this.J = b;
            this.i = this.l = null;
            this.u = [];
            this.C = {};
            SRa(this)
        },
        URa = function(a, b, c, d, e, f) {
            a.info("getAutomaticScreenByIds " + c + " / " + b);
            c || (c = a.C[b]);
            var h = a.Hh(),
                l = c ? Z6(h, c) : null;
            c && (a.J || l) || (l = Z6(h, b));
            if (l) {
                l.uuid = b;
                var m = g8(a, l);
                c8(a.i, m, function(n) {
                    e(n ? m : null)
                })
            } else c ? TRa(a, c, (0, g.D)(function(n) {
                var p = g8(this, new T6({
                    name: d,
                    screenId: c,
                    loungeToken: n,
                    dialId: b || ""
                }));
                c8(this.i, p, function(q) {
                    e(q ? p : null)
                })
            }, a), f) : e(null)
        },
        VRa = function(a, b) {
            for (var c = 0, d = a.screens.length; c < d; ++c)
                if (a.screens[c].name == b) return a.screens[c];
            return null
        },
        WRa = function(a, b, c) {
            c8(a.i, b, c)
        },
        TRa = function(a, b, c, d) {
            a.info("requestLoungeToken_ for " + b);
            var e = {
                postParams: {
                    screen_ids: b
                },
                method: "POST",
                context: a,
                onSuccess: function(f, h) {
                    f = h && h.screens || [];
                    f[0] && f[0].screenId == b ? c(f[0].loungeToken) : d(Error("Missing lounge token in token response"))
                },
                onError: function() {
                    d(Error("Request screen lounge token failed"))
                }
            };
            g.ot(P7(a.B, "/pairing/get_lounge_token_batch"), e)
        },
        XRa = function(a) {
            a.screens = a.l.Hh();
            var b = a.C,
                c = {},
                d;
            for (d in b) c[b[d]] = d;
            b = 0;
            for (d = a.screens.length; b < d; ++b) {
                var e = a.screens[b];
                e.uuid = c[e.id] || ""
            }
            a.info("Updated manual screens: " + W6(a.screens))
        },
        SRa = function(a) {
            h8(a);
            a.l = new Z7(a.B);
            a.l.subscribe("screenChange", (0, g.D)(a.OQ, a));
            XRa(a);
            a.J || (a.u = GQa(g.zz("yt-remote-automatic-screen-cache") || []));
            h8(a);
            a.info("Initializing automatic screens: " + W6(a.u));
            a.i = new b8(a.B, (0, g.D)(a.Hh, a, !0));
            a.i.subscribe("screenChange", (0, g.D)(function() {
                this.Y("onlineScreenChange")
            }, a))
        },
        g8 = function(a, b) {
            var c = a.get(b.id);
            c ? (c.uuid = b.uuid, b = c) : ((c = Z6(a.u, b.uuid)) ? (c.id = b.id, c.token = b.token, b = c) : a.u.push(b), a.J || YRa(a));
            h8(a);
            a.C[b.uuid] = b.id;
            g.yz("yt-remote-device-id-map", a.C, 31536E3);
            return b
        },
        YRa = function(a) {
            a = g.Jo(a.u, function(b) {
                return "shortLived" != b.idType
            });
            g.yz("yt-remote-automatic-screen-cache", g.Qe(a, EQa))
        },
        h8 = function(a) {
            a.C = g.zz("yt-remote-device-id-map") || {}
        },
        i8 = function(a, b, c) {
            g.R.call(this);
            this.Aa = c;
            this.u = a;
            this.i = b;
            this.B = null
        },
        j8 = function(a, b) {
            a.B = b;
            a.Y("sessionScreen", a.B)
        },
        ZRa = function(a, b) {
            a.B && (a.B.token = b, g8(a.u, a.B));
            a.Y("sessionScreen", a.B)
        },
        k8 = function(a, b) {
            S7(a.Aa, b)
        },
        l8 = function(a, b, c) {
            i8.call(this, a, b, "CastSession");
            var d = this;
            this.config_ = c;
            this.l = null;
            this.ea = (0, g.D)(this.RO, this);
            this.ya = (0, g.D)(this.kV, this);
            this.Z = g.ht(function() {
                $Ra(d, null)
            }, 12E4);
            this.J = this.C = this.I = this.L = 0;
            this.xa = !1;
            this.U = "unknown"
        },
        m8 = function(a, b) {
            g.jt(a.J);
            a.J = 0;
            0 == b ? aSa(a) : a.J = g.ht(function() {
                aSa(a)
            }, b)
        },
        aSa = function(a) {
            bSa(a, "getLoungeToken");
            g.jt(a.C);
            a.C = g.ht(function() {
                cSa(a, null)
            }, 3E4)
        },
        bSa = function(a, b) {
            a.info("sendYoutubeMessage_: " + b + " " + g.Jh(void 0));
            var c = {};
            c.type = b;
            a.l ? a.l.sendMessage("urn:x-cast:com.google.youtube.mdx", c, g.Ia, (0, g.D)(function() {
                k8(this, "Failed to send message: " + b + ".")
            }, a)) : k8(a, "Sending yt message without session: " + g.Jh(c))
        },
        n8 = function(a, b) {
            b ? (a.info("onConnectedScreenId_: Received screenId: " + b), a.getScreen() && a.getScreen().id == b || a.XI(b, function(c) {
                j8(a, c)
            }, function() {
                return a.rg()
            }, 5)) : a.rg(Error("Waiting for session status timed out."))
        },
        eSa = function(a, b, c) {
            a.info("onConnectedScreenData_: Received screenData: " + JSON.stringify(b));
            var d = new T6(b);
            dSa(a, d, function(e) {
                e ? (a.xa = !0, g8(a.u, d), j8(a, d), a.U = "unknown", m8(a, c)) : (g.ps(Error("CastSession, RemoteScreen from screenData: " + JSON.stringify(b) + " is not online.")), a.rg())
            }, 5)
        },
        $Ra = function(a, b) {
            g.jt(a.Z);
            a.Z = 0;
            b ? a.config_.enableCastLoungeToken && b.loungeToken ? b.deviceId ? a.getScreen() && a.getScreen().uuid == b.deviceId || (b.loungeTokenRefreshIntervalMs ? eSa(a, {
                name: a.i.friendlyName,
                screenId: b.screenId,
                loungeToken: b.loungeToken,
                dialId: b.deviceId,
                screenIdType: "shortLived"
            }, b.loungeTokenRefreshIntervalMs) : (g.ps(Error("No loungeTokenRefreshIntervalMs presents in mdxSessionStatusData: " + JSON.stringify(b) + ".")), n8(a, b.screenId))) : (g.ps(Error("No device id presents in mdxSessionStatusData: " + JSON.stringify(b) +
                ".")), n8(a, b.screenId)) : n8(a, b.screenId) : a.rg(Error("Waiting for session status timed out."))
        },
        cSa = function(a, b) {
            g.jt(a.C);
            a.C = 0;
            var c = null;
            if (b)
                if (b.loungeToken) {
                    var d;
                    (null == (d = a.getScreen()) ? void 0 : d.token) == b.loungeToken && (c = "staleLoungeToken")
                } else c = "missingLoungeToken";
            else c = "noLoungeTokenResponse";
            c ? (a.info("Did not receive a new lounge token in onLoungeToken_ with data: " + (JSON.stringify(b) + ", error: " + c)), a.U = c, m8(a, 3E4)) : (ZRa(a, b.loungeToken), a.xa = !1, a.U = "unknown", m8(a, b.loungeTokenRefreshIntervalMs))
        },
        dSa = function(a, b, c, d) {
            g.jt(a.I);
            a.I = 0;
            WRa(a.u, b, function(e) {
                e || 0 > d ? c(e) : a.I = g.ht(function() {
                    dSa(a, b, c, d - 1)
                }, 300)
            })
        },
        fSa = function(a) {
            g.jt(a.L);
            a.L = 0;
            g.jt(a.I);
            a.I = 0;
            g.jt(a.Z);
            a.Z = 0;
            g.jt(a.C);
            a.C = 0;
            g.jt(a.J);
            a.J = 0
        },
        o8 = function(a, b, c, d) {
            i8.call(this, a, b, "DialSession");
            this.config_ = d;
            this.l = this.L = null;
            this.ya = "";
            this.Ja = c;
            this.Ka = null;
            this.Z = g.Ia;
            this.U = NaN;
            this.Ga = (0, g.D)(this.SO, this);
            this.C = g.Ia;
            this.J = this.I = 0;
            this.ea = !1;
            this.xa = "unknown"
        },
        p8 = function(a) {
            var b;
            return !!(a.config_.enableDialLoungeToken && (null == (b = a.l) ? 0 : b.getDialAppInfo))
        },
        gSa = function(a) {
            a.C = a.u.AG(a.ya, a.i.label, a.i.friendlyName, p8(a), function(b, c) {
                a.C = g.Ia;
                a.ea = !0;
                j8(a, b);
                "shortLived" == b.idType && 0 < c && q8(a, c)
            }, function(b) {
                a.C = g.Ia;
                a.rg(b)
            })
        },
        hSa = function(a) {
            var b = {};
            b.pairingCode = a.ya;
            b.theme = a.Ja;
            RQa() && (b.env_useStageMdx = 1);
            return g.ri(b)
        },
        r8 = function(a) {
            return new Promise(function(b) {
                a.ya = X6();
                if (a.Ka) {
                    var c = new chrome.cast.DialLaunchResponse(!0, hSa(a));
                    b(c);
                    gSa(a)
                } else a.Z = function() {
                    g.jt(a.U);
                    a.Z = function() {};
                    a.U = NaN;
                    var d = new chrome.cast.DialLaunchResponse(!0, hSa(a));
                    b(d);
                    gSa(a)
                }, a.U = g.ht(function() {
                    a.Z()
                }, 100)
            })
        },
        jSa = function(a, b, c) {
            a.info("initOnConnectedScreenDataPromise_: Received screenData: " + JSON.stringify(b));
            var d = new T6(b);
            return (new Promise(function(e) {
                iSa(a, d, function(f) {
                    f ? (a.ea = !0, g8(a.u, d), j8(a, d), q8(a, c)) : g.ps(Error("DialSession, RemoteScreen from screenData: " + JSON.stringify(b) + " is not online."));
                    e(f)
                }, 5)
            })).then(function(e) {
                return e ? new chrome.cast.DialLaunchResponse(!1) : r8(a)
            })
        },
        kSa = function(a, b) {
            var c = a.L.receiver.label,
                d = a.i.friendlyName;
            return (new Promise(function(e) {
                URa(a.u, c, b, d, function(f) {
                    f && f.token && j8(a, f);
                    e(f)
                }, function(f) {
                    k8(a, "Failed to get DIAL screen: " + f);
                    e(null)
                })
            })).then(function(e) {
                return e && e.token ? new chrome.cast.DialLaunchResponse(!1) : r8(a)
            })
        },
        iSa = function(a, b, c, d) {
            g.jt(a.I);
            a.I = 0;
            WRa(a.u, b, function(e) {
                e || 0 > d ? c(e) : a.I = g.ht(function() {
                    iSa(a, b, c, d - 1)
                }, 300)
            })
        },
        q8 = function(a, b) {
            a.info("getDialAppInfoWithTimeout_ " + b);
            p8(a) && (g.jt(a.J), a.J = 0, 0 == b ? lSa(a) : a.J = g.ht(function() {
                lSa(a)
            }, b))
        },
        lSa = function(a) {
            p8(a) && a.l.getDialAppInfo(function(b) {
                a.info("getDialAppInfo dialLaunchData: " + JSON.stringify(b));
                b = b.extraData || {};
                var c = null;
                if (b.loungeToken) {
                    var d;
                    (null == (d = a.getScreen()) ? void 0 : d.token) == b.loungeToken && (c = "staleLoungeToken")
                } else c = "missingLoungeToken";
                c ? (a.xa = c, q8(a, 3E4)) : (a.ea = !1, a.xa = "unknown", ZRa(a, b.loungeToken), q8(a, b.loungeTokenRefreshIntervalMs))
            }, function(b) {
                a.info("getDialAppInfo error: " + b);
                a.xa = "noLoungeTokenResponse";
                q8(a, 3E4)
            })
        },
        mSa = function(a) {
            g.jt(a.I);
            a.I = 0;
            g.jt(a.J);
            a.J = 0;
            a.C();
            a.C = function() {};
            g.jt(a.U)
        },
        s8 = function(a, b) {
            i8.call(this, a, b, "ManualSession");
            this.l = g.ht((0, g.D)(this.Vr, this, null), 150)
        },
        t8 = function(a, b) {
            g.R.call(this);
            this.config_ = b;
            this.l = a;
            this.L = b.appId || "233637DE";
            this.B = b.theme || "cl";
            this.U = b.disableCastApi || !1;
            this.I = b.forceMirroring || !1;
            this.i = null;
            this.J = !1;
            this.u = [];
            this.C = (0, g.D)(this.fU, this)
        },
        nSa = function(a, b) {
            return b ? g.gb(a.u, function(c) {
                return U6(b, c.label)
            }, a) : null
        },
        u8 = function(a) {
            S7("Controller", a)
        },
        FRa = function(a) {
            window.chrome && chrome.cast && chrome.cast.logMessage && chrome.cast.logMessage(a)
        },
        v8 = function(a) {
            return a.J || !!a.u.length || !!a.i
        },
        w8 = function(a, b, c) {
            b != a.i && (g.ef(a.i), (a.i = b) ? (c ? a.Y("yt-remote-cast2-receiver-resumed",
                b.i) : a.Y("yt-remote-cast2-receiver-selected", b.i), b.subscribe("sessionScreen", (0, g.D)(a.hL, a, b)), b.subscribe("sessionFailed", function() {
                return oSa(a, b)
            }), b.getScreen() ? a.Y("yt-remote-cast2-session-change", b.getScreen()) : c && a.i.Vr(null)) : a.Y("yt-remote-cast2-session-change", null))
        },
        oSa = function(a, b) {
            a.i == b && a.Y("yt-remote-cast2-session-failed")
        },
        pSa = function(a) {
            var b = a.l.zG(),
                c = a.i && a.i.i;
            a = g.Qe(b, function(d) {
                c && U6(d, c.label) && (c = null);
                var e = d.uuid ? d.uuid : d.id,
                    f = nSa(this, d);
                f ? (f.label = e, f.friendlyName = d.name) : (f = new chrome.cast.Receiver(e, d.name), f.receiverType = chrome.cast.ReceiverType.CUSTOM);
                return f
            }, a);
            c && (c.receiverType != chrome.cast.ReceiverType.CUSTOM && (c = new chrome.cast.Receiver(c.label, c.friendlyName), c.receiverType = chrome.cast.ReceiverType.CUSTOM), a.push(c));
            return a
        },
        uSa = function(a, b, c, d) {
            d.disableCastApi ? x8("Cannot initialize because disabled by Mdx config.") : qSa() ? rSa(b, d) && (y8(!0), window.chrome && chrome.cast && chrome.cast.isAvailable ? sSa(a, c) : (window.__onGCastApiAvailable = function(e, f) {
                e ? sSa(a, c) : (z8("Failed to load cast API: " + f), A8(!1), y8(!1), g.Bz("yt-remote-cast-available"), g.Bz("yt-remote-cast-receiver"),
                    tSa(), c(!1))
            }, d.loadCastApiSetupScript ? g.Dz("https://www.gstatic.com/cv/js/sender/v1/cast_sender.js") : 0 <= window.navigator.userAgent.indexOf("Android") && 0 <= window.navigator.userAgent.indexOf("Chrome/") && window.navigator.presentation ? 60 <= f7() && YQa() : !window.chrome || !window.navigator.presentation || 0 <= window.navigator.userAgent.indexOf("Edge") ? h7() : 89 <= f7() ? $Qa() : (i7(), g7(ZQa.map(VQa))))) : x8("Cannot initialize because not running Chrome")
        },
        tSa = function() {
            x8("dispose");
            var a = B8();
            a && a.dispose();
            g.Ga("yt.mdx.remote.cloudview.instance_", null, void 0);
            vSa(!1);
            g.Xu(C8);
            C8.length = 0
        },
        D8 = function() {
            return !!g.zz("yt-remote-cast-installed")
        },
        wSa = function() {
            var a = g.zz("yt-remote-cast-receiver");
            return a ? a.friendlyName : null
        },
        xSa = function() {
            x8("clearCurrentReceiver");
            g.Bz("yt-remote-cast-receiver")
        },
        ySa = function() {
            return D8() ? B8() ? B8().getCastSession() : (z8("getCastSelector: Cast is not initialized."), null) : (z8("getCastSelector: Cast API is not installed!"), null)
        },
        F8 = function() {
            D8() ? B8() ? E8() ? (x8("Requesting cast selector."), B8().requestSession()) : (x8("Wait for cast API to be ready to request the session."), C8.push(g.Wu("yt-remote-cast2-api-ready", F8))) : z8("requestCastSelector: Cast is not initialized.") : z8("requestCastSelector: Cast API is not installed!")
        },
        G8 =
        function(a, b) {
            E8() ? B8().setConnectedScreenStatus(a, b) : z8("setConnectedScreenStatus called before ready.")
        },
        qSa = function() {
            var a = 0 <= g.Yc.search(/ (CrMo|Chrome|CriOS)\//);
            return g.dj || a
        },
        zSa = function(a, b) {
            B8().init(a, b)
        },
        rSa = function(a, b) {
            var c = !1;
            B8() || (a = new t8(a, b), a.subscribe("yt-remote-cast2-availability-change", function(d) {
                g.yz("yt-remote-cast-available", d);
                R6("yt-remote-cast2-availability-change", d)
            }), a.subscribe("yt-remote-cast2-receiver-selected", function(d) {
                x8("onReceiverSelected: " + d.friendlyName);
                g.yz("yt-remote-cast-receiver", d);
                R6("yt-remote-cast2-receiver-selected", d)
            }), a.subscribe("yt-remote-cast2-receiver-resumed", function(d) {
                x8("onReceiverResumed: " + d.friendlyName);
                g.yz("yt-remote-cast-receiver", d);
                R6("yt-remote-cast2-receiver-resumed", d)
            }), a.subscribe("yt-remote-cast2-session-change", function(d) {
                x8("onSessionChange: " + V6(d));
                d || g.Bz("yt-remote-cast-receiver");
                R6("yt-remote-cast2-session-change", d)
            }), g.Ga("yt.mdx.remote.cloudview.instance_", a, void 0), c = !0);
            x8("cloudview.createSingleton_: " + c);
            return c
        },
        B8 = function() {
            return g.Ha("yt.mdx.remote.cloudview.instance_")
        },
        sSa = function(a, b) {
            A8(!0);
            y8(!1);
            zSa(a, function(c) {
                c ? (vSa(!0), g.Yu("yt-remote-cast2-api-ready")) : (z8("Failed to initialize cast API."), A8(!1), g.Bz("yt-remote-cast-available"), g.Bz("yt-remote-cast-receiver"), tSa());
                b(c)
            })
        },
        x8 = function(a) {
            S7("cloudview", a)
        },
        z8 = function(a) {
            S7("cloudview", a)
        },
        A8 = function(a) {
            x8("setCastInstalled_ " + a);
            g.yz("yt-remote-cast-installed", a)
        },
        E8 = function() {
            return !!g.Ha("yt.mdx.remote.cloudview.apiReady_")
        },
        vSa = function(a) {
            x8("setApiReady_ " + a);
            g.Ga("yt.mdx.remote.cloudview.apiReady_", a, void 0)
        },
        y8 = function(a) {
            g.Ga("yt.mdx.remote.cloudview.initializing_", a, void 0)
        },
        H8 = function(a) {
            this.index = -1;
            this.videoId = this.listId = "";
            this.volume = this.playerState = -1;
            this.muted = !1;
            this.audioTrackId = null;
            this.I = this.J = 0;
            this.trackData = null;
            this.hasNext = this.xk = !1;
            this.L = this.C = this.i = this.B = 0;
            this.u = NaN;
            this.l = !1;
            this.reset(a)
        },
        I8 = function(a) {
            a.audioTrackId = null;
            a.trackData = null;
            a.playerState = -1;
            a.xk = !1;
            a.hasNext = !1;
            a.J = 0;
            a.I = g.Sa();
            a.B = 0;
            a.i = 0;
            a.C = 0;
            a.L = 0;
            a.u = NaN;
            a.l = !1
        },
        J8 = function(a) {
            return a.xc() ? (g.Sa() - a.I) / 1E3 : 0
        },
        K8 = function(a, b) {
            a.J = b;
            a.I = g.Sa()
        },
        L8 = function(a) {
            switch (a.playerState) {
                case 1:
                case 1081:
                    return (g.Sa() - a.I) / 1E3 + a.J;
                case -1E3:
                    return 0
            }
            return a.J
        },
        M8 = function(a, b, c) {
            var d = a.videoId;
            a.videoId = b;
            a.index = c;
            b != d && I8(a)
        },
        N8 = function(a) {
            var b = {};
            b.index = a.index;
            b.listId = a.listId;
            b.videoId = a.videoId;
            b.playerState = a.playerState;
            b.volume = a.volume;
            b.muted = a.muted;
            b.audioTrackId = a.audioTrackId;
            b.trackData = g.$b(a.trackData);
            b.hasPrevious = a.xk;
            b.hasNext = a.hasNext;
            b.playerTime = a.J;
            b.playerTimeAt = a.I;
            b.seekableStart = a.B;
            b.seekableEnd = a.i;
            b.duration = a.C;
            b.loadedTime = a.L;
            b.liveIngestionTime = a.u;
            return b
        },
        P8 = function(a, b) {
            g.R.call(this);
            this.Qa = 0;
            this.u = a;
            this.C = [];
            this.B = new BRa;
            this.l = this.i = null;
            this.L = (0, g.D)(this.CS, this);
            this.I = (0, g.D)(this.Lv, this);
            this.J = (0, g.D)(this.BS, this);
            this.U = (0, g.D)(this.KS, this);
            var c = 0;
            a ? (c = a.getProxyState(), 3 != c && (a.subscribe("proxyStateChange", this.PE, this), ASa(this))) : c = 3;
            0 != c && (b ? this.PE(c) : g.ht((0, g.D)(function() {
                this.PE(c)
            }, this), 0));
            (a = ySa()) && O8(this, a);
            this.subscribe("yt-remote-cast2-session-change", this.U)
        },
        Q8 = function(a) {
            return new H8(a.u.getPlayerContextData())
        },
        ASa = function(a) {
            g.Eb("nowAutoplaying autoplayDismissed remotePlayerChange remoteQueueChange autoplayModeChange autoplayUpNext previousNextChange multiStateLoopEnabled".split(" "), function(b) {
                this.C.push(this.u.subscribe(b, g.Ra(this.cU, b), this))
            }, a)
        },
        BSa = function(a) {
            g.Eb(a.C, function(b) {
                this.u.unsubscribeByKey(b)
            }, a);
            a.C.length = 0
        },
        R8 = function(a) {
            return 1 == a.getState()
        },
        S8 = function(a, b) {
            var c = a.B;
            50 > c.i.length + c.l.length && a.B.l.push(b)
        },
        U8 = function(a, b, c) {
            var d = Q8(a);
            K8(d, c); - 1E3 != d.playerState && (d.playerState = b);
            T8(a, d)
        },
        V8 = function(a, b, c) {
            a.u.sendMessage(b, c)
        },
        T8 = function(a, b) {
            BSa(a);
            a.u.setPlayerContextData(N8(b));
            ASa(a)
        },
        O8 = function(a, b) {
            a.l && (a.l.removeUpdateListener(a.L), a.l.removeMediaListener(a.I), a.Lv(null));
            a.l = b;
            a.l && (S7("CP", "Setting cast session: " + a.l.sessionId), a.l.addUpdateListener(a.L), a.l.addMediaListener(a.I), a.l.media.length && a.Lv(a.l.media[0]))
        },
        CSa = function(a) {
            var b = a.i.media,
                c = a.i.customData;
            if (b && c) {
                var d = Q8(a);
                b.contentId != d.videoId && S7("CP", "Cast changing video to: " + b.contentId);
                d.videoId = b.contentId;
                d.playerState = c.playerState;
                K8(d, a.i.getEstimatedTime());
                T8(a, d)
            } else S7("CP", "No cast media video. Ignoring state update.")
        },
        W8 = function(a, b, c) {
            return (0, g.D)(function(d) {
                this.Yd("Failed to " + b + " with cast v2 channel. Error code: " + d.code);
                d.code != chrome.cast.ErrorCode.TIMEOUT && (this.Yd("Retrying " + b + " using MDx browser channel."), V8(this, b, c))
            }, a)
        },
        X8 = function(a, b, c, d) {
            d = void 0 === d ? !1 : d;
            g.R.call(this);
            this.C = NaN;
            this.xa = !1;
            this.L = this.J = this.Z = this.ea = NaN;
            this.U = [];
            this.B = this.I = this.u = this.hc = this.i = null;
            this.Ga = a;
            this.Aa = d;
            this.U.push(g.nu(window, "beforeunload", (0, g.D)(this.AQ, this)));
            this.l = [];
            this.hc = new H8;
            this.Ka = b.id;
            this.ya = b.idType;
            this.i = DSa(this, c);
            this.i.subscribe("handlerOpened", this.HS, this);
            this.i.subscribe("handlerClosed", this.DS, this);
            this.i.subscribe("handlerError", this.ES, this);
            this.i.subscribe("handlerMessage", this.GS, this);
            this.i.Oz(b.token);
            this.subscribe("remoteQueueChange",
                function() {
                    var e = this.hc.videoId;
                    g.Cz() && g.yz("yt-remote-session-video-id", e)
                }, this)
        },
        ESa = function(a) {
            return g.gb(a.l, function(b) {
                return "LOUNGE_SCREEN" == b.type
            })
        },
        Y8 = function(a) {
            S7("conn", a)
        },
        DSa = function(a, b) {
            return new L7(P7(a.Ga, "/bc"), b, !1, function() {
                return a.EG()
            }, "shortLived" == a.ya)
        },
        Z8 = function(a, b) {
            a.Y("proxyStateChange", b)
        },
        FSa = function(a) {
            a.C = g.ht((0, g.D)(function() {
                Y8("Connecting timeout");
                this.wr(1)
            }, a), 2E4)
        },
        $8 = function(a) {
            g.jt(a.C);
            a.C = NaN
        },
        a9 = function(a) {
            g.jt(a.ea);
            a.ea = NaN
        },
        GSa = function(a) {
            b9(a);
            a.Z = g.ht((0, g.D)(function() {
                c9(this, "getNowPlaying")
            }, a), 2E4)
        },
        b9 = function(a) {
            g.jt(a.Z);
            a.Z = NaN
        },
        ISa = function(a, b) {
            var c = null;
            if (b) {
                var d = ESa(a);
                d && (c = {
                    clientName: d.clientName,
                    deviceMake: d.brand,
                    deviceModel: d.model,
                    osVersion: d.osVersion
                })
            }
            g.Ga("yt.mdx.remote.remoteClient_", c, void 0);
            b && ($8(a), a9(a));
            c = N7(a.i) && isNaN(a.C);
            b == c ? b && (Z8(a, 1), c9(a, "getSubtitlesTrack")) : b ? (a.WI() && a.hc.reset(), Z8(a, 1), c9(a, "getNowPlaying"), HSa(a)) : a.wr(1)
        },
        JSa = function(a, b) {
            var c = b.params.videoId;
            delete b.params.videoId;
            c == a.hc.videoId && (g.Vb(b.params) ? a.hc.trackData = null : a.hc.trackData = b.params, a.Y("remotePlayerChange"))
        },
        KSa = function(a, b) {
            var c = b.params.videoId || b.params.video_id,
                d = parseInt(b.params.currentIndex, 10);
            a.hc.listId = b.params.listId || a.hc.listId;
            M8(a.hc, c, d);
            a.Y("remoteQueueChange")
        },
        MSa = function(a, b) {
            b.params = b.params || {};
            KSa(a, b);
            LSa(a, b);
            a.Y("autoplayDismissed")
        },
        LSa = function(a, b) {
            var c = parseInt(b.params.currentTime || b.params.current_time, 10);
            K8(a.hc, isNaN(c) ? 0 : c);
            c = parseInt(b.params.state, 10);
            c = isNaN(c) ? -1 : c; - 1 == c && -1E3 == a.hc.playerState && (c = -1E3);
            a.hc.playerState = c;
            c = Number(b.params.loadedTime);
            a.hc.L = isNaN(c) ? 0 : c;
            a.hc.Bj(Number(b.params.duration));
            c = a.hc;
            var d = Number(b.params.liveIngestionTime);
            c.u = d;
            c.l = isNaN(d) ? !1 : !0;
            c = a.hc;
            d = Number(b.params.seekableStartTime);
            b = Number(b.params.seekableEndTime);
            c.B = isNaN(d) ? 0 : d;
            c.i = isNaN(b) ? 0 : b;
            1 == a.hc.playerState ? GSa(a) : b9(a);
            a.Y("remotePlayerChange")
        },
        NSa = function(a, b) {
            if (-1E3 != a.hc.playerState) {
                var c =
                    1085;
                switch (parseInt(b.params.adState, 10)) {
                    case 1:
                        c = 1081;
                        break;
                    case 2:
                        c = 1084;
                        break;
                    case 0:
                        c = 1083
                }
                a.hc.playerState = c;
                b = parseInt(b.params.currentTime, 10);
                K8(a.hc, isNaN(b) ? 0 : b);
                a.Y("remotePlayerChange")
            }
        },
        OSa = function(a, b) {
            var c = "true" == b.params.muted;
            a.hc.volume = parseInt(b.params.volume, 10);
            a.hc.muted = c;
            a.Y("remotePlayerChange")
        },
        PSa = function(a, b) {
            a.I = b.params.videoId;
            a.Y("nowAutoplaying", parseInt(b.params.timeout, 10))
        },
        QSa = function(a, b) {
            var c = "true" == b.params.hasNext;
            a.hc.xk = "true" == b.params.hasPrevious;
            a.hc.hasNext = c;
            a.Y("previousNextChange")
        },
        HSa = function(a) {
            g.jt(a.L);
            a.L = g.ht((0, g.D)(a.wr, a, 1), 864E5)
        },
        c9 = function(a, b, c) {
            c ? Y8("Sending: action=" + b + ", params=" + g.Jh(c)) : Y8("Sending: action=" + b);
            a.i.sendMessage(b, c)
        },
        d9 = function(a) {
            W7.call(this, "ScreenServiceProxy");
            this.Ne = a;
            this.i = [];
            this.i.push(this.Ne.$_s("screenChange", (0, g.D)(this.WO, this)));
            this.i.push(this.Ne.$_s("onlineScreenChange", (0, g.D)(this.GT, this)))
        },
        USa = function(a, b) {
            QQa();
            if (!e7 || !e7.get("yt-remote-disable-remote-module-for-dev")) {
                b = g.P("MDX_CONFIG") || b;
                IQa();
                c7();
                e9 || (e9 = new O7(b ? b.loungeApiHost : void 0), RQa() && (e9.i = "/api/loungedev"));
                f9 || (f9 = g.Ha("yt.mdx.remote.deferredProxies_") || [], g.Ga("yt.mdx.remote.deferredProxies_", f9, void 0));
                RSa();
                var c = g9();
                if (!c) {
                    var d = new f8(e9, b ? b.disableAutomaticScreenCache || !1 : !1);
                    g.Ga("yt.mdx.remote.screenService_", d, void 0);
                    c = g9();
                    var e = {};
                    b && (e = {
                        appId: b.appId,
                        disableDial: b.disableDial,
                        theme: b.theme,
                        loadCastApiSetupScript: b.loadCastApiSetupScript,
                        disableCastApi: b.disableCastApi,
                        enableDialLoungeToken: b.enableDialLoungeToken,
                        enableCastLoungeToken: b.enableCastLoungeToken,
                        forceMirroring: b.forceMirroring
                    });
                    g.Ga("yt.mdx.remote.enableConnectWithInitialState_", b ? b.enableConnectWithInitialState || !1 : !1, void 0);
                    uSa(a, d, function(f) {
                        f ? h9() && G8(h9(), "YouTube TV") : d.subscribe("onlineScreenChange", function() {
                            R6("yt-remote-receiver-availability-change")
                        })
                    }, e)
                }
                b && !g.Ha("yt.mdx.remote.initialized_") && (g.Ga("yt.mdx.remote.initialized_", !0, void 0), i9("Initializing: " +
                        g.Jh(b)), j9.push(g.Wu("yt-remote-cast2-api-ready", function() {
                        R6("yt-remote-api-ready")
                    })), j9.push(g.Wu("yt-remote-cast2-availability-change", function() {
                        R6("yt-remote-receiver-availability-change")
                    })), j9.push(g.Wu("yt-remote-cast2-receiver-selected", function() {
                        k9(null);
                        R6("yt-remote-auto-connect", "cast-selector-receiver")
                    })), j9.push(g.Wu("yt-remote-cast2-receiver-resumed", function() {
                        R6("yt-remote-receiver-resumed", "cast-selector-receiver")
                    })), j9.push(g.Wu("yt-remote-cast2-session-change", SSa)), j9.push(g.Wu("yt-remote-connection-change", function(f) {
                        f ? G8(h9(), "YouTube TV") : l9() || (G8(null, null), xSa())
                    })), j9.push(g.Wu("yt-remote-cast2-session-failed", function() {
                        R6("yt-remote-connection-failed")
                    })), a = m9(), b.isAuto && (a.id += "#dial"), e = b.capabilities || [], g.ks("desktop_enable_autoplay") &&
                    e.push("atp"), 0 < e.length && (a.capabilities = e), a.name = b.device, a.app = b.app, (b = b.theme) && (a.theme = b), i9(" -- with channel params: " + g.Jh(a)), a ? (g.yz("yt-remote-session-app", a.app), g.yz("yt-remote-session-name", a.name)) : (g.Bz("yt-remote-session-app"), g.Bz("yt-remote-session-name")), g.Ga("yt.mdx.remote.channelParams_", a, void 0), c.start(), h9() || TSa())
            }
        },
        VSa = function() {
            var a = g9().Ne.$_gos();
            var b = n9();
            b && o9() && (Y6(a, b) || a.push(b));
            return HQa(a)
        },
        p9 = function() {
            var a = WSa();
            !a && D8() && wSa() && (a = {
                key: "cast-selector-receiver",
                name: wSa()
            });
            return a
        },
        WSa = function() {
            var a = VSa(),
                b = n9();
            b || (b = l9());
            return g.gb(a, function(c) {
                return b && U6(b, c.key) ? !0 : !1
            })
        },
        n9 = function() {
            var a = h9();
            if (!a) return null;
            var b = g9().Hh();
            return Z6(b, a)
        },
        SSa = function(a) {
            i9("remote.onCastSessionChange_: " + V6(a));
            if (a) {
                var b = n9();
                if (b && b.id == a.id) {
                    if (G8(b.id, "YouTube TV"), "shortLived" == a.idType && (a = a.token)) q9 && (q9.token = a), (b = o9()) && b.Oz(a)
                } else b && r9(), s9(a, 1)
            } else o9() && r9()
        },
        r9 = function() {
            E8() ? B8().stopSession() : z8("stopSession called before API ready.");
            var a = o9();
            a && (a.disconnect(1), t9(null))
        },
        u9 = function() {
            var a = o9();
            return !!a && 3 != a.getProxyState()
        },
        i9 = function(a) {
            S7("remote", a)
        },
        g9 = function() {
            if (!v9) {
                var a = g.Ha("yt.mdx.remote.screenService_");
                v9 = a ? new d9(a) : null
            }
            return v9
        },
        h9 = function() {
            return g.Ha("yt.mdx.remote.currentScreenId_")
        },
        XSa = function(a) {
            g.Ga("yt.mdx.remote.currentScreenId_", a, void 0)
        },
        YSa = function() {
            return g.Ha("yt.mdx.remote.connectData_")
        },
        k9 = function(a) {
            g.Ga("yt.mdx.remote.connectData_", a, void 0)
        },
        o9 = function() {
            return g.Ha("yt.mdx.remote.connection_")
        },
        t9 = function(a) {
            var b = o9();
            k9(null);
            a || XSa("");
            g.Ga("yt.mdx.remote.connection_", a, void 0);
            f9 && (g.Eb(f9, function(c) {
                c(a)
            }), f9.length = 0);
            b && !a ? R6("yt-remote-connection-change", !1) : !b && a && R6("yt-remote-connection-change", !0)
        },
        l9 = function() {
            var a = g.Cz();
            if (!a) return null;
            var b = g9();
            if (!b) return null;
            b = b.Hh();
            return Z6(b, a)
        },
        s9 = function(a, b) {
            h9();
            n9() && n9();
            if (w9) q9 = a;
            else {
                XSa(a.id);
                var c = g.Ha("yt.mdx.remote.enableConnectWithInitialState_") || !1;
                a = new X8(e9, a, m9(), c);
                a.connect(b, YSa());
                a.subscribe("beforeDisconnect", function(d) {
                    R6("yt-remote-before-disconnect", d)
                });
                a.subscribe("beforeDispose", function() {
                    o9() && (o9(), t9(null))
                });
                a.subscribe("browserChannelAuthError", function() {
                    var d = n9();
                    d && "shortLived" == d.idType && (E8() ? B8().handleBrowserChannelAuthError() : z8("refreshLoungeToken called before API ready."))
                });
                t9(a)
            }
        },
        TSa = function() {
            var a = l9();
            a ? (i9("Resume connection to: " + V6(a)), s9(a, 0)) : (d7(), xSa(), i9("Skipping connecting because no session screen found."))
        },
        RSa = function() {
            var a = m9();
            if (g.Vb(a)) {
                a = b7();
                var b = g.zz("yt-remote-session-name") || "",
                    c = g.zz("yt-remote-session-app") || "";
                a = {
                    device: "REMOTE_CONTROL",
                    id: a,
                    name: b,
                    app: c,
                    mdxVersion: 3
                };
                g.Ga("yt.mdx.remote.channelParams_", a, void 0)
            }
        },
        m9 = function() {
            return g.Ha("yt.mdx.remote.channelParams_") || {}
        },
        x9 = function(a, b, c) {
            g.G.call(this);
            var d = this;
            this.l = a;
            this.G = b;
            this.Qb = c;
            this.events = new g.eN(this);
            this.Z = this.events.N(this.G, "onVolumeChange", function(e) {
                ZSa(d, e)
            });
            this.C = !1;
            this.suggestion = null;
            this.I = new g.jK(64);
            this.i = new g.K(this.dM, 500, this);
            this.u = new g.K(this.eM, 1E3, this);
            this.L = new j7(this.uW, 0, this);
            this.B = {};
            this.U = new g.K(this.MM, 1E3, this);
            this.J = new k7(this.seekTo, 1E3, this);
            this.ea = g.Ia;
            g.J(this, this.events);
            this.events.N(b, "onCaptionsTrackListChanged", this.qT);
            this.events.N(b, "captionschanged", this.zS);
            this.events.N(b, "captionssettingschanged", this.kM);
            this.events.N(b, "videoplayerreset", this.kz);
            this.events.N(b, "mdxautoplaycancel", function() {
                d.Qb.sI()
            });
            a = this.Qb;
            a.isDisposed();
            a.subscribe("proxyStateChange", this.dL, this);
            a.subscribe("remotePlayerChange", this.Qv, this);
            a.subscribe("remoteQueueChange", this.kz, this);
            a.subscribe("previousNextChange", this.aL, this);
            a.subscribe("nowAutoplaying", this.UK, this);
            a.subscribe("autoplayDismissed", this.xK, this);
            g.J(this, this.i);
            g.J(this, this.u);
            g.J(this, this.L);
            g.J(this, this.U);
            g.J(this, this.J);
            this.kM();
            this.kz();
            this.Qv()
        },
        ZSa = function(a, b) {
            if (y9(a)) {
                a.Qb.unsubscribe("remotePlayerChange", a.Qv, a);
                var c = Math.round(b.volume);
                b = !!b.muted;
                var d = Q8(a.Qb);
                if (c !== d.volume || b !== d.muted) a.Qb.setVolume(c, b), a.U.start();
                a.Qb.subscribe("remotePlayerChange", a.Qv, a)
            }
        },
        $Sa = function(a) {
            a.Nb(0);
            a.i.stop();
            a.Rb(new g.jK(64))
        },
        z9 = function(a, b) {
            if (y9(a) && !a.C) {
                var c = null;
                b && (c = {
                    style: a.G.getSubtitlesUserSettings()
                }, g.cc(c, b));
                a.Qb.DG(a.G.getVideoData(1).videoId, c);
                a.B = Q8(a.Qb).trackData
            }
        },
        A9 = function(a, b) {
            var c = a.G.getPlaylist();
            if (null === c || void 0 === c ? 0 : c.listId) {
                var d = c.index;
                var e = c.listId.toString()
            }
            c = a.G.getVideoData(1);
            a.Qb.playVideo(c.videoId, b, d, e, c.playerParams, c.Sa, xQa(c));
            a.Rb(new g.jK(1))
        },
        aTa = function(a, b) {
            if (b) {
                var c = a.G.getOption("captions", "tracklist", {
                    sJ: 1
                });
                c && c.length ? (a.G.setOption("captions", "track", b), a.C = !1) : (a.G.loadModule("captions"), a.C = !0)
            } else a.G.setOption("captions", "track", {})
        },
        y9 = function(a) {
            return Q8(a.Qb).videoId === a.G.getVideoData(1).videoId
        },
        B9 = function() {
            g.W.call(this, {
                D: "div",
                K: "ytp-mdx-manual-pairing-popup-dialog",
                V: {
                    role: "dialog"
                },
                S: [{
                    D: "div",
                    K: "ytp-mdx-manual-pairing-popup-dialog-inner-content",
                    S: [{
                        D: "div",
                        K: "ytp-mdx-manual-pairing-popup-title",
                        ra: "Connecting to your TV on web using a code will be going away soon"
                    }, {
                        D: "div",
                        K: "ytp-mdx-manual-pairing-popup-buttons",
                        S: [{
                            D: "button",
                            Fa: ["ytp-button", "ytp-mdx-manual-pairing-popup-learn-more"],
                            ra: "Learn more"
                        }, {
                            D: "button",
                            Fa: ["ytp-button", "ytp-mdx-manual-pairing-popup-ok"],
                            ra: "OK"
                        }]
                    }]
                }]
            });
            this.i = new g.PL(this, 250);
            this.learnMoreButton =
                this.Da("ytp-mdx-manual-pairing-popup-learn-more");
            this.okButton = this.Da("ytp-mdx-manual-pairing-popup-ok");
            g.J(this, this.i);
            this.N(this.learnMoreButton, "click", this.l);
            this.N(this.okButton, "click", this.u)
        },
        C9 = function() {
            g.W.call(this, {
                D: "div",
                K: "ytp-mdx-popup-dialog",
                V: {
                    role: "dialog"
                },
                S: [{
                    D: "div",
                    K: "ytp-mdx-popup-dialog-inner-content",
                    S: [{
                        D: "div",
                        K: "ytp-mdx-popup-title",
                        ra: "You're signed out"
                    }, {
                        D: "div",
                        K: "ytp-mdx-popup-description",
                        ra: "Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer."
                    }, {
                        D: "div",
                        K: "ytp-mdx-privacy-popup-buttons",
                        S: [{
                            D: "button",
                            Fa: ["ytp-button", "ytp-mdx-privacy-popup-cancel"],
                            ra: "Cancel"
                        }, {
                            D: "button",
                            Fa: ["ytp-button",
                                "ytp-mdx-privacy-popup-confirm"
                            ],
                            ra: "Confirm"
                        }]
                    }]
                }]
            });
            this.i = new g.PL(this, 250);
            this.cancelButton = this.Da("ytp-mdx-privacy-popup-cancel");
            this.confirmButton = this.Da("ytp-mdx-privacy-popup-confirm");
            g.J(this, this.i);
            this.N(this.cancelButton, "click", this.l);
            this.N(this.confirmButton, "click", this.u)
        },
        D9 = function(a) {
            g.W.call(this, {
                D: "div",
                K: "ytp-remote",
                S: [{
                    D: "div",
                    K: "ytp-remote-display-status",
                    S: [{
                        D: "div",
                        K: "ytp-remote-display-status-icon",
                        S: [g.Fra()]
                    }, {
                        D: "div",
                        K: "ytp-remote-display-status-text",
                        ra: "{{statustext}}"
                    }]
                }]
            });
            this.api = a;
            this.i = new g.PL(this, 250);
            g.J(this, this.i);
            this.N(a, "presentingplayerstatechange", this.l);
            bTa(this, a.ub())
        },
        bTa = function(a, b) {
            if (3 === a.api.getPresentingPlayerType()) {
                var c = {
                    RECEIVER_NAME: a.api.getOption("remote", "currentReceiver").name
                };
                b = g.V(b, 128) ? g.JI("Error on $RECEIVER_NAME", c) : b.xc() || g.V(b, 4) ? g.JI("Playing on $RECEIVER_NAME", c) : g.JI("Connected to $RECEIVER_NAME", c);
                a.Ta("statustext", b);
                a.i.show()
            } else a.i.hide()
        },
        E9 = function(a, b) {
            g.eQ.call(this, "Play on", 0, a, b);
            this.G = a;
            this.Rn = {};
            this.N(a, "onMdxReceiversChange", this.C);
            this.N(a, "presentingplayerstatechange", this.C);
            this.C()
        },
        F9 = function(a) {
            g.oN.call(this, a);
            this.mj = {
                key: X6(),
                name: "This computer"
            };
            this.yh = null;
            this.subscriptions = [];
            this.pE = this.Qb = null;
            this.Rn = [this.mj];
            this.Mm = this.mj;
            this.od = new g.jK(64);
            this.QJ = 0;
            this.mf = -1;
            this.Zr = null;
            this.Uv = this.Jy = !1;
            this.cm = this.zs = null;
            if (!g.zF(this.player.T()) && !g.AF(this.player.T())) {
                a = this.player;
                var b = g.SM(a);
                b && (b = b.jn()) && (b = new E9(a, b), g.J(this, b));
                b = new D9(a);
                g.J(this, b);
                g.bN(a, b.element, 4);
                this.zs = new C9;
                g.J(this, this.zs);
                g.bN(a, this.zs.element, 4);
                g.T(this.player.T().experiments, "pair_servlet_deprecation_warning_enabled") &&
                    !g.T(this.player.T().experiments, "deprecate_pair_servlet_enabled") && (this.Zr = new B9, g.J(this, this.Zr), g.bN(a, this.Zr.element, 4));
                this.Uv = !!l9();
                this.Jy = !!g.zz("yt-remote-manual-pairing-warning-shown")
            }
        },
        G9 = function(a) {
            a.cm && (a.player.removeEventListener("presentingplayerstatechange", a.cm), a.cm = null)
        },
        cTa = function(a, b, c) {
            a.od = c;
            a.player.Y("presentingplayerstatechange", new g.wI(c, b))
        },
        dTa = function(a, b, c) {
            var d = !1;
            1 === b ? d = !a.Uv : 2 === b && (d = !a.Jy);
            d && g.yI(c, 8) && (a.player.pauseVideo(), G9(a))
        },
        H9 = function(a, b) {
            if (b.key !== a.Mm.key)
                if (b.key === a.mj.key) r9();
                else {
                    if (a.Zr && !a.Jy && b !== a.mj && "cast-selector-receiver" !== b.key && g.RF(a.player.T())) eTa(a);
                    else {
                        var c;
                        (c = !g.T(a.player.T().experiments, "mdx_enable_privacy_disclosure_ui")) || (c = ((c = g.P("PLAYER_CONFIG")) && c.args && void 0 !== c.args.authuser ? !0 : !(!g.P("SESSION_INDEX") && !g.P("LOGGED_IN"))) || a.Uv || !a.zs);
                        (c ? 0 : g.RF(a.player.T()) || g.UF(a.player.T())) && fTa(a)
                    }
                    a.Mm = b;
                    if (!a.player.T().X("disable_mdx_connection_in_mdx_module_for_music_web") || !g.AF(a.player.T())) {
                        var d = a.player.getPlaylistId();
                        c = a.player.getVideoData(1);
                        var e = c.videoId;
                        if (!d && !e || (2 === a.player.getAppState() || 1 === a.player.getAppState()) && g.T(a.player.T().experiments, "should_clear_video_data_on_player_cued_unstarted")) a = null;
                        else {
                            var f = a.player.getPlaylist();
                            if (f) {
                                var h = [];
                                for (var l = 0; l < f.length; l++) h[l] = g.kN(f, l).videoId
                            } else h = [e];
                            f = a.player.getCurrentTime(1);
                            a = {
                                videoIds: h,
                                listId: d,
                                videoId: e,
                                playerParams: c.playerParams,
                                clickTrackingParams: c.Sa,
                                index: Math.max(a.player.getPlaylistIndex(), 0),
                                currentTime: 0 === f ? void 0 : f
                            };
                            (c = xQa(c)) && (a.locationInfo = c)
                        }
                        i9("Connecting to: " +
                            g.Jh(b));
                        "cast-selector-receiver" == b.key ? (k9(a || null), b = a || null, E8() ? B8().setLaunchParams(b) : z8("setLaunchParams called before ready.")) : !a && u9() && h9() == b.key ? R6("yt-remote-connection-change", !0) : (r9(), k9(a || null), a = g9().Hh(), (b = Z6(a, b.key)) && s9(b, 1))
                    }
                }
        },
        fTa = function(a) {
            a.player.ub().xc() ? a.player.pauseVideo() : (a.cm = function(b) {
                dTa(a, 1, b)
            }, a.player.addEventListener("presentingplayerstatechange", a.cm));
            a.zs && a.zs.bd();
            o9() || (w9 = !0)
        },
        eTa = function(a) {
            a.player.ub().xc() ? a.player.pauseVideo() : (a.cm = function(b) {
                dTa(a, 2, b)
            }, a.player.addEventListener("presentingplayerstatechange", a.cm));
            a.Zr && a.Zr.bd();
            o9() || (w9 = !0)
        },
        fRa = {
            "\x00": "\\0",
            "\b": "\\b",
            "\f": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t",
            "\x0B": "\\x0B",
            '"': '\\"',
            "\\": "\\\\",
            "<": "\\u003C"
        },
        w7 = {
            "'": "\\'"
        },
        DQa = {
            tX: "atp",
            G7: "ska",
            u6: "que",
            D4: "mus",
            F7: "sus",
            M0: "dsp",
            Q6: "seq",
            g4: "mic",
            J_: "dpa",
            HX: "cds",
            B4: "mlm"
        },
        e7, a7 = "",
        XQa = SQa("loadCastFramework") || SQa("loadCastApplicationFramework"),
        ZQa = ["pkedcjkdefgpdelpbcmbmeomcjbeemfm", "enhhojjnijigcajfphajepfemndkmdlo"];
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    g.Ta(j7, g.G);
    g.k = j7.prototype;
    g.k.KO = function(a) {
        this.B = arguments;
        this.i = !1;
        this.Ib ? this.u = g.Sa() + this.Nf : this.Ib = g.jh(this.C, this.Nf)
    };
    g.k.stop = function() {
        this.Ib && (g.C.clearTimeout(this.Ib), this.Ib = null);
        this.u = null;
        this.i = !1;
        this.B = []
    };
    g.k.pause = function() {
        ++this.l
    };
    g.k.resume = function() {
        this.l && (--this.l, !this.l && this.i && (this.i = !1, this.I.apply(null, this.B)))
    };
    g.k.va = function() {
        this.stop();
        j7.Xd.va.call(this)
    };
    g.k.LO = function() {
        this.Ib && (g.C.clearTimeout(this.Ib), this.Ib = null);
        this.u ? (this.Ib = g.jh(this.C, this.u - g.Sa()), this.u = null) : this.l ? this.i = !0 : (this.i = !1, this.I.apply(null, this.B))
    };
    g.x(k7, g.G);
    g.k = k7.prototype;
    g.k.yG = function(a) {
        this.u = arguments;
        this.Ib || this.l ? this.i = !0 : l7(this)
    };
    g.k.stop = function() {
        this.Ib && (g.C.clearTimeout(this.Ib), this.Ib = null, this.i = !1, this.u = null)
    };
    g.k.pause = function() {
        this.l++
    };
    g.k.resume = function() {
        this.l--;
        this.l || !this.i || this.Ib || (this.i = !1, l7(this))
    };
    g.k.va = function() {
        g.G.prototype.va.call(this);
        this.stop()
    };
    m7.prototype.stringify = function(a) {
        return g.C.JSON.stringify(a, void 0)
    };
    m7.prototype.parse = function(a) {
        return g.C.JSON.parse(a, void 0)
    };
    var o7 = new g.Kf;
    g.x(aRa, g.kf);
    g.k = q7.prototype;
    g.k.Co = null;
    g.k.mm = !1;
    g.k.Ws = null;
    g.k.EF = null;
    g.k.Es = null;
    g.k.Ps = null;
    g.k.Fm = null;
    g.k.Vn = null;
    g.k.Xp = null;
    g.k.If = null;
    g.k.rA = 0;
    g.k.Gj = null;
    g.k.nA = null;
    g.k.Bm = null;
    g.k.Gt = -1;
    g.k.TL = !0;
    g.k.So = !1;
    g.k.cB = 0;
    g.k.Cz = null;
    var dRa = {},
        t7 = {};
    g.k = q7.prototype;
    g.k.setTimeout = function(a) {
        this.u = a
    };
    g.k.MO = function(a) {
        a = a.target;
        var b = this.Cz;
        b && 3 == g.Gi(a) ? b.yG() : this.UM(a)
    };
    g.k.UM = function(a) {
        try {
            if (a == this.If) a: {
                var b = g.Gi(this.If),
                    c = this.If.l,
                    d = this.If.getStatus();
                if (g.ke && !g.de(10) || g.lg && !g.ce("420+")) {
                    if (4 > b) break a
                } else if (3 > b || 3 == b && !g.Ti(this.If)) break a;this.So || 4 != b || 7 == c || (8 == c || 0 >= d ? this.i.qj(3) : this.i.qj(2));x7(this);
                var e = this.If.getStatus();this.Gt = e;
                var f = g.Ti(this.If);
                if (this.mm = 200 == e) {
                    4 == b && u7(this);
                    if (this.C) {
                        for (a = !0; !this.So && this.rA < f.length;) {
                            var h = eRa(this, f);
                            if (h == t7) {
                                4 == b && (this.Bm = 4, p7(15), a = !1);
                                break
                            } else if (h == dRa) {
                                this.Bm = 4;
                                p7(16);
                                a = !1;
                                break
                            } else y7(this, h)
                        }
                        4 == b && 0 == f.length && (this.Bm = 1, p7(17), a = !1);
                        this.mm = this.mm && a;
                        a || (u7(this), v7(this))
                    } else y7(this, f);
                    this.mm && !this.So && (4 == b ? this.i.Vw(this) : (this.mm = !1, s7(this)))
                } else 400 == e && 0 < f.indexOf("Unknown SID") ? (this.Bm = 3, p7(13)) : (this.Bm = 0, p7(14)),
                u7(this),
                v7(this)
            }
        } catch (l) {
            this.If && g.Ti(this.If)
        } finally {}
    };
    g.k.aV = function(a) {
        n7((0, g.D)(this.ZU, this, a), 0)
    };
    g.k.ZU = function(a) {
        this.So || (x7(this), y7(this, a), s7(this))
    };
    g.k.lL = function(a) {
        n7((0, g.D)(this.YU, this, a), 0)
    };
    g.k.YU = function(a) {
        this.So || (u7(this), this.mm = a, this.i.Vw(this), this.i.qj(4))
    };
    g.k.cancel = function() {
        this.So = !0;
        u7(this)
    };
    g.k.hV = function() {
        this.Ws = null;
        var a = Date.now();
        0 <= a - this.EF ? (2 != this.Ps && this.i.qj(3), u7(this), this.Bm = 2, p7(18), v7(this)) : hRa(this, this.EF - a)
    };
    g.k.getLastError = function() {
        return this.Bm
    };
    g.k = kRa.prototype;
    g.k.dB = null;
    g.k.nh = null;
    g.k.Dz = !1;
    g.k.fM = null;
    g.k.Ex = null;
    g.k.tD = null;
    g.k.eB = null;
    g.k.Qa = null;
    g.k.Vk = -1;
    g.k.Ht = null;
    g.k.Yt = null;
    g.k.connect = function(a) {
        this.eB = a;
        a = A7(this.i, null, this.eB);
        p7(3);
        this.fM = Date.now();
        var b = this.i.J;
        null != b ? (this.Ht = b[0], (this.Yt = b[1]) ? (this.Qa = 1, lRa(this)) : (this.Qa = 2, C7(this))) : (O6(a, "MODE", "init"), this.nh = new q7(this, void 0, void 0, void 0), this.nh.Co = this.dB, r7(this.nh, a, !1, null, !0), this.Qa = 0)
    };
    g.k.GP = function(a) {
        if (a) this.Qa = 2, C7(this);
        else {
            p7(4);
            var b = this.i;
            b.Vj = b.Km.Vk;
            J7(b, 9)
        }
        a && this.qj(2)
    };
    g.k.hC = function(a) {
        return this.i.hC(a)
    };
    g.k.abort = function() {
        this.nh && (this.nh.cancel(), this.nh = null);
        this.Vk = -1
    };
    g.k.jf = function() {
        return !1
    };
    g.k.eL = function(a, b) {
        this.Vk = a.Gt;
        if (0 == this.Qa)
            if (b) {
                try {
                    var c = this.l.parse(b)
                } catch (d) {
                    a = this.i;
                    a.Vj = this.Vk;
                    J7(a, 2);
                    return
                }
                this.Ht = c[0];
                this.Yt = c[1]
            } else a = this.i, a.Vj = this.Vk, J7(a, 2);
        else if (2 == this.Qa)
            if (this.Dz) p7(7), this.tD = Date.now();
            else if ("11111" == b) {
            if (p7(6), this.Dz = !0, this.Ex = Date.now(), a = this.Ex - this.fM, !g.ke || g.de(10) || 500 > a) this.Vk = 200, this.nh.cancel(), p7(12), B7(this.i, this, !0)
        } else p7(8), this.Ex = this.tD = Date.now(), this.Dz = !1
    };
    g.k.Vw = function() {
        this.Vk = this.nh.Gt;
        if (this.nh.mm) 0 == this.Qa ? this.Yt ? (this.Qa = 1, lRa(this)) : (this.Qa = 2, C7(this)) : 2 == this.Qa && ((!g.ke || g.de(10) ? !this.Dz : 200 > this.tD - this.Ex) ? (p7(11), B7(this.i, this, !1)) : (p7(12), B7(this.i, this, !0)));
        else {
            0 == this.Qa ? p7(9) : 2 == this.Qa && p7(10);
            var a = this.i;
            this.nh.getLastError();
            a.Vj = this.Vk;
            J7(a, 2)
        }
    };
    g.k.qw = function() {
        return this.i.qw()
    };
    g.k.isActive = function() {
        return this.i.isActive()
    };
    g.k.qj = function(a) {
        this.i.qj(a)
    };
    g.k = D7.prototype;
    g.k.Uj = null;
    g.k.Du = null;
    g.k.Ug = null;
    g.k.Ce = null;
    g.k.fB = null;
    g.k.Fx = null;
    g.k.JH = null;
    g.k.Ww = null;
    g.k.Ev = 0;
    g.k.RR = 0;
    g.k.Jf = null;
    g.k.Tm = null;
    g.k.rl = null;
    g.k.ep = null;
    g.k.Km = null;
    g.k.lA = null;
    g.k.Ur = -1;
    g.k.PJ = -1;
    g.k.Vj = -1;
    g.k.Ar = 0;
    g.k.Yq = 0;
    g.k.To = 8;
    g.Ta(nRa, g.kf);
    g.Ta(oRa, g.kf);
    g.k = D7.prototype;
    g.k.connect = function(a, b, c, d, e) {
        p7(0);
        this.fB = b;
        this.Du = c || {};
        d && void 0 !== e && (this.Du.OSID = d, this.Du.OAID = e);
        this.C ? (n7((0, g.D)(this.dI, this, a), 100), sRa(this)) : this.dI(a)
    };
    g.k.dI = function(a) {
        this.Km = new kRa(this);
        this.Km.dB = this.Uj;
        this.Km.l = this.B;
        this.Km.connect(a)
    };
    g.k.jf = function() {
        return 0 == this.Qa
    };
    g.k.getState = function() {
        return this.Qa
    };
    g.k.jL = function(a) {
        this.Tm = null;
        wRa(this, a)
    };
    g.k.iL = function() {
        this.rl = null;
        this.Ce = new q7(this, this.l, "rpc", this.I);
        this.Ce.Co = this.Uj;
        this.Ce.cB = 0;
        var a = this.JH.clone();
        g.sk(a, "RID", "rpc");
        g.sk(a, "SID", this.l);
        g.sk(a, "CI", this.lA ? "0" : "1");
        g.sk(a, "AID", this.Ur);
        E7(this, a);
        if (!g.ke || g.de(10)) g.sk(a, "TYPE", "xmlhttp"), r7(this.Ce, a, !0, this.Ww, !1);
        else {
            g.sk(a, "TYPE", "html");
            var b = this.Ce,
                c = !!this.Ww;
            b.Ps = 3;
            b.Fm = N6(a.clone());
            gRa(b, c)
        }
    };
    g.k.eL = function(a, b) {
        if (0 != this.Qa && (this.Ce == a || this.Ug == a))
            if (this.Vj = a.Gt, this.Ug == a && 3 == this.Qa)
                if (7 < this.To) {
                    try {
                        var c = this.B.parse(b)
                    } catch (d) {
                        c = null
                    }
                    if (Array.isArray(c) && 3 == c.length)
                        if (a = c, 0 == a[0]) a: {
                            if (!this.rl) {
                                if (this.Ce)
                                    if (this.Ce.Es + 3E3 < this.Ug.Es) G7(this), this.Ce.cancel(), this.Ce = null;
                                    else break a;
                                I7(this);
                                p7(19)
                            }
                        }
                    else this.PJ = a[1], 0 < this.PJ - this.Ur && 37500 > a[2] && this.lA && 0 == this.Yq && !this.ep && (this.ep = n7((0, g.D)(this.wS, this), 6E3));
                    else J7(this, 11)
                } else null != b && J7(this, 11);
        else if (this.Ce ==
            a && G7(this), !g.uc(b))
            for (a = this.B.parse(b), b = 0; b < a.length; b++) c = a[b], this.Ur = c[0], c = c[1], 2 == this.Qa ? "c" == c[0] ? (this.l = c[1], this.Ww = c[2], c = c[3], null != c ? this.To = c : this.To = 6, this.Qa = 3, this.Jf && this.Jf.ZH(), this.JH = A7(this, this.qw() ? this.Ww : null, this.fB), xRa(this)) : "stop" == c[0] && J7(this, 7) : 3 == this.Qa && ("stop" == c[0] ? J7(this, 7) : "noop" != c[0] && this.Jf && this.Jf.YH(c), this.Yq = 0)
    };
    g.k.wS = function() {
        null != this.ep && (this.ep = null, this.Ce.cancel(), this.Ce = null, I7(this), p7(20))
    };
    g.k.Vw = function(a) {
        if (this.Ce == a) {
            G7(this);
            this.Ce = null;
            var b = 2
        } else if (this.Ug == a) this.Ug = null, b = 1;
        else return;
        this.Vj = a.Gt;
        if (0 != this.Qa)
            if (a.mm)
                if (1 == b) {
                    b = Date.now() - a.Es;
                    var c = o7;
                    c.dispatchEvent(new nRa(c, a.Xp ? a.Xp.length : 0, b, this.Ar));
                    F7(this);
                    this.u.length = 0
                } else xRa(this);
        else {
            c = a.getLastError();
            var d;
            if (!(d = 3 == c || 7 == c || 0 == c && 0 < this.Vj)) {
                if (d = 1 == b) this.Ug || this.Tm || 1 == this.Qa || 2 <= this.Ar ? d = !1 : (this.Tm = n7((0, g.D)(this.jL, this, a), yRa(this, this.Ar)), this.Ar++, d = !0);
                d = !(d || 2 == b && I7(this))
            }
            if (d) switch (c) {
                case 1:
                    J7(this,
                        5);
                    break;
                case 4:
                    J7(this, 10);
                    break;
                case 3:
                    J7(this, 6);
                    break;
                case 7:
                    J7(this, 12);
                    break;
                default:
                    J7(this, 2)
            }
        }
    };
    g.k.gQ = function(a) {
        if (!g.kb(arguments, this.Qa)) throw Error("Unexpected channel state: " + this.Qa);
    };
    g.k.dW = function(a) {
        a ? p7(2) : (p7(1), zRa(this, 8))
    };
    g.k.hC = function(a) {
        if (a) throw Error("Can't create secondary domain capable XhrIo object.");
        a = new g.Ai;
        a.L = !1;
        return a
    };
    g.k.isActive = function() {
        return !!this.Jf && this.Jf.isActive(this)
    };
    g.k.qj = function(a) {
        var b = o7;
        b.dispatchEvent(new oRa(b, a))
    };
    g.k.qw = function() {
        return !(!g.ke || g.de(10))
    };
    g.k = ARa.prototype;
    g.k.ZH = function() {};
    g.k.YH = function() {};
    g.k.XH = function() {};
    g.k.UB = function() {};
    g.k.JI = function() {
        return {}
    };
    g.k.isActive = function() {
        return !0
    };
    g.k = BRa.prototype;
    g.k.isEmpty = function() {
        return 0 === this.i.length && 0 === this.l.length
    };
    g.k.clear = function() {
        this.i = [];
        this.l = []
    };
    g.k.contains = function(a) {
        return g.kb(this.i, a) || g.kb(this.l, a)
    };
    g.k.remove = function(a) {
        var b = this.i;
        var c = (0, g.BKa)(b, a);
        0 <= c ? (g.ob(b, c), b = !0) : b = !1;
        return b || g.pb(this.l, a)
    };
    g.k.Xg = function() {
        for (var a = [], b = this.i.length - 1; 0 <= b; --b) a.push(this.i[b]);
        var c = this.l.length;
        for (b = 0; b < c; ++b) a.push(this.l[b]);
        return a
    };
    g.Ta(K7, g.G);
    g.k = K7.prototype;
    g.k.SU = function() {
        this.Nf = Math.min(3E5, 2 * this.Nf);
        this.u();
        this.l && this.start()
    };
    g.k.start = function() {
        var a = this.Nf + 15E3 * Math.random();
        g.Gq(this.i, a);
        this.l = Date.now() + a
    };
    g.k.stop = function() {
        this.i.stop();
        this.l = 0
    };
    g.k.isActive = function() {
        return this.i.isActive()
    };
    g.k.reset = function() {
        this.i.stop();
        this.Nf = 5E3
    };
    g.Ta(L7, ARa);
    g.k = L7.prototype;
    g.k.subscribe = function(a, b, c) {
        return this.u.subscribe(a, b, c)
    };
    g.k.unsubscribe = function(a, b, c) {
        return this.u.unsubscribe(a, b, c)
    };
    g.k.Uf = function(a) {
        return this.u.Uf(a)
    };
    g.k.Y = function(a, b) {
        return this.u.Y.apply(this.u, arguments)
    };
    g.k.dispose = function() {
        this.Z || (this.Z = !0, g.ef(this.u), ERa(this), g.ef(this.l), this.l = null, this.ea = function() {
            return ""
        })
    };
    g.k.isDisposed = function() {
        return this.Z
    };
    g.k.connect = function(a, b, c) {
        if (!this.i || 2 != this.i.getState()) {
            this.U = "";
            this.l.stop();
            this.C = a || null;
            this.B = b || 0;
            a = this.xa + "/test";
            b = this.xa + "/bind";
            var d = new D7(c ? c.firstTestResults : null, c ? c.secondTestResults : null, this.ya),
                e = this.i;
            e && (e.Jf = null);
            d.Jf = this;
            this.i = d;
            M7(this);
            if (this.i) {
                d = g.P("ID_TOKEN");
                var f = this.i.Uj || {};
                d ? f["x-youtube-identity-token"] = d : delete f["x-youtube-identity-token"];
                this.i.Uj = f
            }
            e ? (3 != e.getState() && 0 == uRa(e) || e.getState(), this.i.connect(a, b, this.I, e.l, e.Ur)) : c ? this.i.connect(a,
                b, this.I, c.sessionId, c.arrayId) : this.i.connect(a, b, this.I)
        }
    };
    g.k.sendMessage = function(a, b) {
        a = {
            _sc: a
        };
        b && g.cc(a, b);
        this.l.isActive() || 2 == (this.i ? this.i.getState() : 0) ? this.J.push(a) : N7(this) && (M7(this), tRa(this.i, a))
    };
    g.k.ZH = function() {
        this.l.reset();
        this.C = null;
        this.B = 0;
        if (this.J.length) {
            var a = this.J;
            this.J = [];
            for (var b = 0, c = a.length; b < c; ++b) tRa(this.i, a[b])
        }
        this.Y("handlerOpened")
    };
    g.k.XH = function(a) {
        var b = 2 == a && 401 == this.i.Vj;
        4 == a || b || this.l.start();
        this.Y("handlerError", a, b)
    };
    g.k.UB = function(a) {
        if (!this.l.isActive()) this.Y("handlerClosed");
        else if (a)
            for (var b = 0, c = a.length; b < c; ++b) {
                var d = a[b].map;
                d && this.J.push(d)
            }
    };
    g.k.JI = function() {
        var a = {
            v: 2
        };
        this.U && (a.gsessionid = this.U);
        0 != this.B && (a.ui = "" + this.B);
        0 != this.L && (a.ui = "" + this.L);
        this.C && g.cc(a, this.C);
        return a
    };
    g.k.YH = function(a) {
        "S" == a[0] ? this.U = a[1] : "gracefulReconnect" == a[0] ? (this.l.start(), rRa(this.i)) : this.Y("handlerMessage", new CRa(a[0], a[1]))
    };
    g.k.Oz = function(a) {
        (this.I.loungeIdToken = a) || this.l.stop();
        if (this.Aa && this.i) {
            var b = this.i.Uj || {};
            a ? b["X-YouTube-LoungeId-Token"] = a : delete b["X-YouTube-LoungeId-Token"];
            this.i.Uj = b
        }
    };
    g.k.IV = function() {
        this.l.isActive();
        0 == uRa(this.i) && this.connect(this.C, this.B)
    };
    O7.prototype.B = function(a, b, c, d) {
        b ? a(d) : a({
            text: c.responseText
        })
    };
    O7.prototype.u = function(a, b) {
        a(Error("Request error: " + b.status))
    };
    O7.prototype.C = function(a) {
        a(Error("request timed out"))
    };
    var LRa = Date.now(),
        R7 = null,
        U7 = Array(50),
        T7 = -1,
        V7 = !1;
    g.Ta(W7, g.R);
    W7.prototype.Hh = function() {
        return this.screens
    };
    W7.prototype.contains = function(a) {
        return !!Y6(this.screens, a)
    };
    W7.prototype.get = function(a) {
        return a ? Z6(this.screens, a) : null
    };
    W7.prototype.info = function(a) {
        S7(this.I, a)
    };
    g.x(X7, g.R);
    g.k = X7.prototype;
    g.k.start = function() {
        !this.i && isNaN(this.Ib) && this.sL()
    };
    g.k.stop = function() {
        this.i && (this.i.abort(), this.i = null);
        isNaN(this.Ib) || (g.jt(this.Ib), this.Ib = NaN)
    };
    g.k.va = function() {
        this.stop();
        g.R.prototype.va.call(this)
    };
    g.k.sL = function() {
        this.Ib = NaN;
        this.i = g.ot(P7(this.u, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: this.J
            },
            timeout: 5E3,
            onSuccess: (0, g.D)(this.OO, this),
            onError: (0, g.D)(this.NO, this),
            onTimeout: (0, g.D)(this.PO, this)
        })
    };
    g.k.OO = function(a, b) {
        this.i = null;
        a = b.screen || {};
        a.dialId = this.B;
        a.name = this.I;
        b = -1;
        this.C && a.shortLivedLoungeToken && a.shortLivedLoungeToken.value && a.shortLivedLoungeToken.refreshIntervalMs && (a.screenIdType = "shortLived", a.loungeToken = a.shortLivedLoungeToken.value, b = a.shortLivedLoungeToken.refreshIntervalMs);
        this.Y("pairingComplete", new T6(a), b)
    };
    g.k.NO = function(a) {
        this.i = null;
        a.status && 404 == a.status ? this.l >= gTa.length ? this.Y("pairingFailed", Error("DIAL polling timed out")) : (a = gTa[this.l], this.Ib = g.ht((0, g.D)(this.sL, this), a), this.l++) : this.Y("pairingFailed", Error("Server error " + a.status))
    };
    g.k.PO = function() {
        this.i = null;
        this.Y("pairingFailed", Error("Server not responding"))
    };
    var gTa = [2E3, 2E3, 1E3, 1E3, 1E3, 2E3, 2E3, 5E3, 5E3, 1E4];
    g.Ta(Z7, W7);
    g.k = Z7.prototype;
    g.k.start = function() {
        Y7(this) && this.Y("screenChange");
        !g.zz("yt-remote-lounge-token-expiration") && PRa(this);
        g.jt(this.i);
        this.i = g.ht((0, g.D)(this.start, this), 1E4)
    };
    g.k.add = function(a, b) {
        Y7(this);
        MRa(this, a);
        $7(this, !1);
        this.Y("screenChange");
        b(a);
        a.token || PRa(this)
    };
    g.k.remove = function(a, b) {
        var c = Y7(this);
        ORa(this, a) && ($7(this, !1), c = !0);
        b(a);
        c && this.Y("screenChange")
    };
    g.k.jA = function(a, b, c, d) {
        var e = Y7(this),
            f = this.get(a.id);
        f ? (f.name != b && (f.name = b, $7(this, !1), e = !0), c(a)) : d(Error("no such local screen."));
        e && this.Y("screenChange")
    };
    g.k.va = function() {
        g.jt(this.i);
        Z7.Xd.va.call(this)
    };
    g.k.FQ = function(a) {
        Y7(this);
        var b = this.screens.length;
        a = a && a.screens || [];
        for (var c = 0, d = a.length; c < d; ++c) {
            var e = a[c],
                f = this.get(e.screenId);
            f && (f.token = e.loungeToken, --b)
        }
        $7(this, !b);
        b && S7(this.I, "Missed " + b + " lounge tokens.")
    };
    g.k.EQ = function(a) {
        S7(this.I, "Requesting lounge tokens failed: " + a)
    };
    g.x(b8, g.R);
    g.k = b8.prototype;
    g.k.start = function() {
        var a = parseInt(g.zz("yt-remote-fast-check-period") || "0", 10);
        (this.B = g.Sa() - 144E5 < a ? 0 : a) ? e8(this): (this.B = g.Sa() + 3E5, g.yz("yt-remote-fast-check-period", this.B), this.zE())
    };
    g.k.isEmpty = function() {
        return g.Vb(this.i)
    };
    g.k.update = function() {
        a8("Updating availability on schedule.");
        var a = this.I(),
            b = g.Ib(this.i, function(c, d) {
                return c && !!Z6(a, d)
            }, this);
        d8(this, b)
    };
    g.k.va = function() {
        g.jt(this.u);
        this.u = NaN;
        this.l && (this.l.abort(), this.l = null);
        g.R.prototype.va.call(this)
    };
    g.k.zE = function() {
        g.jt(this.u);
        this.u = NaN;
        this.l && this.l.abort();
        var a = RRa(this);
        if (P6(a)) {
            var b = P7(this.C, "/pairing/get_screen_availability");
            this.l = Q7(this.C, b, {
                lounge_token: g.Pb(a).join(",")
            }, (0, g.D)(this.zU, this, a), (0, g.D)(this.xU, this))
        } else d8(this, {}), e8(this)
    };
    g.k.zU = function(a, b) {
        this.l = null;
        var c = g.Pb(RRa(this));
        if (g.Bb(c, g.Pb(a))) {
            b = b.screens || [];
            c = {};
            for (var d = 0, e = b.length; d < e; ++d) c[a[b[d].loungeToken]] = "online" == b[d].status;
            d8(this, c);
            e8(this)
        } else this.Yd("Changing Screen set during request."), this.zE()
    };
    g.k.xU = function(a) {
        this.Yd("Screen availability failed: " + a);
        this.l = null;
        e8(this)
    };
    g.k.Yd = function(a) {
        S7("OnlineScreenService", a)
    };
    g.Ta(f8, W7);
    g.k = f8.prototype;
    g.k.start = function() {
        this.l.start();
        this.i.start();
        this.screens.length && (this.Y("screenChange"), this.i.isEmpty() || this.Y("onlineScreenChange"))
    };
    g.k.add = function(a, b, c) {
        this.l.add(a, b, c)
    };
    g.k.remove = function(a, b, c) {
        this.l.remove(a, b, c);
        this.i.update()
    };
    g.k.jA = function(a, b, c, d) {
        this.l.contains(a) ? this.l.jA(a, b, c, d) : (a = "Updating name of unknown screen: " + a.name, S7(this.I, a), d(Error(a)))
    };
    g.k.Hh = function(a) {
        return a ? this.screens : g.rb(this.screens, g.Jo(this.u, function(b) {
            return !this.contains(b)
        }, this))
    };
    g.k.zG = function() {
        return g.Jo(this.Hh(!0), function(a) {
            return !!this.i.i[a.id]
        }, this)
    };
    g.k.AG = function(a, b, c, d, e, f) {
        var h = this;
        this.info("getDialScreenByPairingCode " + a + " / " + b);
        var l = new X7(this.B, a, b, c, d);
        l.subscribe("pairingComplete", function(m, n) {
            g.ef(l);
            e(g8(h, m), n)
        });
        l.subscribe("pairingFailed", function(m) {
            g.ef(l);
            f(m)
        });
        l.start();
        return (0, g.D)(l.stop, l)
    };
    g.k.QO = function(a, b, c, d) {
        g.ot(P7(this.B, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: a
            },
            timeout: 5E3,
            onSuccess: (0, g.D)(function(e, f) {
                e = new T6(f.screen || {});
                if (!e.name || VRa(this, e.name)) {
                    a: {
                        f = e.name;
                        for (var h = 2, l = b(f, h); VRa(this, l);) {
                            h++;
                            if (20 < h) break a;
                            l = b(f, h)
                        }
                        f = l
                    }
                    e.name = f
                }
                c(g8(this, e))
            }, this),
            onError: (0, g.D)(function(e) {
                d(Error("pairing request failed: " + e.status))
            }, this),
            onTimeout: (0, g.D)(function() {
                d(Error("pairing request timed out."))
            }, this)
        })
    };
    g.k.va = function() {
        g.ef(this.l);
        g.ef(this.i);
        f8.Xd.va.call(this)
    };
    g.k.OQ = function() {
        XRa(this);
        this.Y("screenChange");
        this.i.update()
    };
    f8.prototype.dispose = f8.prototype.dispose;
    g.Ta(i8, g.R);
    g.k = i8.prototype;
    g.k.getScreen = function() {
        return this.B
    };
    g.k.rg = function(a) {
        this.isDisposed() || (a && (k8(this, "" + a), this.Y("sessionFailed")), this.B = null, this.Y("sessionScreen", null))
    };
    g.k.info = function(a) {
        S7(this.Aa, a)
    };
    g.k.BG = function() {
        return null
    };
    g.k.NE = function(a) {
        var b = this.i;
        a ? (b.displayStatus = new chrome.cast.ReceiverDisplayStatus(a, []), b.displayStatus.showStop = !0) : b.displayStatus = null;
        chrome.cast.setReceiverDisplayStatus(b, (0, g.D)(function() {
            this.info("Updated receiver status for " + b.friendlyName + ": " + a)
        }, this), (0, g.D)(function() {
            k8(this, "Failed to update receiver status for: " + b.friendlyName)
        }, this))
    };
    g.k.va = function() {
        this.NE("");
        i8.Xd.va.call(this)
    };
    g.x(l8, i8);
    g.k = l8.prototype;
    g.k.ME = function(a) {
        if (this.l) {
            if (this.l == a) return;
            k8(this, "Overriding cast session with new session object");
            fSa(this);
            this.xa = !1;
            this.U = "unknown";
            this.l.removeUpdateListener(this.ea);
            this.l.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.ya)
        }
        this.l = a;
        this.l.addUpdateListener(this.ea);
        this.l.addMessageListener("urn:x-cast:com.google.youtube.mdx", this.ya);
        bSa(this, "getMdxSessionStatus")
    };
    g.k.Vr = function(a) {
        this.info("launchWithParams no-op for Cast: " + g.Jh(a))
    };
    g.k.stop = function() {
        this.l ? this.l.stop((0, g.D)(function() {
            this.rg()
        }, this), (0, g.D)(function() {
            this.rg(Error("Failed to stop receiver app."))
        }, this)) : this.rg(Error("Stopping cast device without session."))
    };
    g.k.NE = function() {};
    g.k.va = function() {
        this.info("disposeInternal");
        fSa(this);
        this.l && (this.l.removeUpdateListener(this.ea), this.l.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.ya));
        this.l = null;
        i8.prototype.va.call(this)
    };
    g.k.kV = function(a, b) {
        if (!this.isDisposed())
            if (b)
                if (b = Q6(b), g.Ma(b)) switch (a = "" + b.type, b = b.data || {}, this.info("onYoutubeMessage_: " + a + " " + g.Jh(b)), a) {
                    case "mdxSessionStatus":
                        $Ra(this, b);
                        break;
                    case "loungeToken":
                        cSa(this, b);
                        break;
                    default:
                        k8(this, "Unknown youtube message: " + a)
                } else k8(this, "Unable to parse message.");
                else k8(this, "No data in message.")
    };
    g.k.XI = function(a, b, c, d) {
        g.jt(this.L);
        this.L = 0;
        URa(this.u, this.i.label, a, this.i.friendlyName, (0, g.D)(function(e) {
            e ? b(e) : 0 <= d ? (k8(this, "Screen " + a + " appears to be offline. " + d + " retries left."), this.L = g.ht((0, g.D)(this.XI, this, a, b, c, d - 1), 300)) : c(Error("Unable to fetch screen."))
        }, this), c)
    };
    g.k.BG = function() {
        return this.l
    };
    g.k.RO = function(a) {
        this.isDisposed() || a || (k8(this, "Cast session died."), this.rg())
    };
    g.x(o8, i8);
    g.k = o8.prototype;
    g.k.ME = function(a) {
        this.l = a;
        this.l.addUpdateListener(this.Ga)
    };
    g.k.Vr = function(a) {
        this.Ka = a;
        this.Z()
    };
    g.k.stop = function() {
        mSa(this);
        this.l ? this.l.stop((0, g.D)(this.rg, this, null), (0, g.D)(this.rg, this, "Failed to stop DIAL device.")) : this.rg()
    };
    g.k.va = function() {
        mSa(this);
        this.l && this.l.removeUpdateListener(this.Ga);
        this.l = null;
        i8.prototype.va.call(this)
    };
    g.k.SO = function(a) {
        this.isDisposed() || a || (k8(this, "DIAL session died."), this.C(), this.C = g.Ia, this.rg())
    };
    g.x(s8, i8);
    s8.prototype.stop = function() {
        this.rg()
    };
    s8.prototype.ME = function() {};
    s8.prototype.Vr = function() {
        g.jt(this.l);
        this.l = NaN;
        var a = Z6(this.u.Hh(), this.i.label);
        a ? j8(this, a) : this.rg(Error("No such screen"))
    };
    s8.prototype.va = function() {
        g.jt(this.l);
        this.l = NaN;
        i8.prototype.va.call(this)
    };
    g.x(t8, g.R);
    g.k = t8.prototype;
    g.k.init = function(a, b) {
        chrome.cast.timeout.requestSession = 3E4;
        var c = new chrome.cast.SessionRequest(this.L);
        this.U || (c.dialRequest = new chrome.cast.DialRequest("YouTube"));
        var d = chrome.cast.AutoJoinPolicy.TAB_AND_ORIGIN_SCOPED;
        a = a || this.I ? chrome.cast.DefaultActionPolicy.CAST_THIS_TAB : chrome.cast.DefaultActionPolicy.CREATE_SESSION;
        var e = (0, g.D)(this.iU, this);
        c = new chrome.cast.ApiConfig(c, (0, g.D)(this.fL, this), e, d, a);
        c.customDialLaunchCallback = (0, g.D)(this.SS, this);
        chrome.cast.initialize(c, (0, g.D)(function() {
            this.isDisposed() ||
                (chrome.cast.addReceiverActionListener(this.C), IRa(), this.l.subscribe("onlineScreenChange", (0, g.D)(this.CG, this)), this.u = pSa(this), chrome.cast.setCustomReceivers(this.u, g.Ia, (0, g.D)(function(f) {
                    this.Yd("Failed to set initial custom receivers: " + g.Jh(f))
                }, this)), this.Y("yt-remote-cast2-availability-change", v8(this)), b(!0))
        }, this), (0, g.D)(function(f) {
            this.Yd("Failed to initialize API: " + g.Jh(f));
            b(!1)
        }, this))
    };
    g.k.NV = function(a, b) {
        u8("Setting connected screen ID: " + a + " -> " + b);
        if (this.i) {
            var c = this.i.getScreen();
            if (!a || c && c.id != a) u8("Unsetting old screen status: " + this.i.i.friendlyName), w8(this, null)
        }
        if (a && b) {
            if (!this.i) {
                c = Z6(this.l.Hh(), a);
                if (!c) {
                    u8("setConnectedScreenStatus: Unknown screen.");
                    return
                }
                if ("shortLived" == c.idType) {
                    u8("setConnectedScreenStatus: Screen with id type to be short lived.");
                    return
                }
                a = nSa(this, c);
                a || (u8("setConnectedScreenStatus: Connected receiver not custom..."), a = new chrome.cast.Receiver(c.uuid ?
                    c.uuid : c.id, c.name), a.receiverType = chrome.cast.ReceiverType.CUSTOM, this.u.push(a), chrome.cast.setCustomReceivers(this.u, g.Ia, (0, g.D)(function(d) {
                    this.Yd("Failed to set initial custom receivers: " + g.Jh(d))
                }, this)));
                u8("setConnectedScreenStatus: new active receiver: " + a.friendlyName);
                w8(this, new s8(this.l, a), !0)
            }
            this.i.NE(b)
        } else u8("setConnectedScreenStatus: no screen.")
    };
    g.k.OV = function(a) {
        this.isDisposed() ? this.Yd("Setting connection data on disposed cast v2") : this.i ? this.i.Vr(a) : this.Yd("Setting connection data without a session")
    };
    g.k.UO = function() {
        this.isDisposed() ? this.Yd("Stopping session on disposed cast v2") : this.i ? (this.i.stop(), w8(this, null)) : u8("Stopping non-existing session")
    };
    g.k.requestSession = function() {
        chrome.cast.requestSession((0, g.D)(this.fL, this), (0, g.D)(this.CU, this))
    };
    g.k.va = function() {
        this.l.unsubscribe("onlineScreenChange", (0, g.D)(this.CG, this));
        window.chrome && chrome.cast && chrome.cast.removeReceiverActionListener(this.C);
        var a = FRa,
            b = g.Ha("yt.mdx.remote.debug.handlers_");
        g.pb(b || [], a);
        g.ef(this.i);
        g.R.prototype.va.call(this)
    };
    g.k.Yd = function(a) {
        S7("Controller", a)
    };
    g.k.hL = function(a, b) {
        this.i == a && (b || w8(this, null), this.Y("yt-remote-cast2-session-change", b))
    };
    g.k.fU = function(a, b) {
        if (!this.isDisposed())
            if (a) switch (a.friendlyName = chrome.cast.unescape(a.friendlyName), u8("onReceiverAction_ " + a.label + " / " + a.friendlyName + "-- " + b), b) {
                case chrome.cast.ReceiverAction.CAST:
                    if (this.i)
                        if (this.i.i.label != a.label) u8("onReceiverAction_: Stopping active receiver: " + this.i.i.friendlyName), this.i.stop();
                        else {
                            u8("onReceiverAction_: Casting to active receiver.");
                            this.i.getScreen() && this.Y("yt-remote-cast2-session-change", this.i.getScreen());
                            break
                        }
                    switch (a.receiverType) {
                        case chrome.cast.ReceiverType.CUSTOM:
                            w8(this,
                                new s8(this.l, a));
                            break;
                        case chrome.cast.ReceiverType.DIAL:
                            w8(this, new o8(this.l, a, this.B, this.config_));
                            break;
                        case chrome.cast.ReceiverType.CAST:
                            w8(this, new l8(this.l, a, this.config_));
                            break;
                        default:
                            this.Yd("Unknown receiver type: " + a.receiverType)
                    }
                    break;
                case chrome.cast.ReceiverAction.STOP:
                    this.i && this.i.i.label == a.label ? this.i.stop() : this.Yd("Stopping receiver w/o session: " + a.friendlyName)
            } else this.Yd("onReceiverAction_ called without receiver.")
    };
    g.k.SS = function(a) {
        if (this.isDisposed()) return Promise.reject(Error("disposed"));
        var b = a.receiver;
        b.receiverType != chrome.cast.ReceiverType.DIAL && (this.Yd("Not DIAL receiver: " + b.friendlyName), b.receiverType = chrome.cast.ReceiverType.DIAL);
        var c = this.i ? this.i.i : null;
        if (!c || c.label != b.label) return this.Yd("Receiving DIAL launch request for non-clicked DIAL receiver: " + b.friendlyName), Promise.reject(Error("illegal DIAL launch"));
        if (c && c.label == b.label && c.receiverType != chrome.cast.ReceiverType.DIAL) {
            if (this.i.getScreen()) return u8("Reselecting dial screen."),
                this.Y("yt-remote-cast2-session-change", this.i.getScreen()), Promise.resolve(new chrome.cast.DialLaunchResponse(!1));
            this.Yd('Changing CAST intent from "' + c.receiverType + '" to "dial" for ' + b.friendlyName);
            w8(this, new o8(this.l, b, this.B, this.config_))
        }
        b = this.i;
        b.L = a;
        b.L.appState == chrome.cast.DialAppState.RUNNING ? (a = b.L.extraData || {}, c = a.screenId || null, p8(b) && a.loungeToken ? a.loungeTokenRefreshIntervalMs ? a = jSa(b, {
            name: b.i.friendlyName,
            screenId: a.screenId,
            loungeToken: a.loungeToken,
            dialId: b.L.receiver.label,
            screenIdType: "shortLived"
        }, a.loungeTokenRefreshIntervalMs) : (g.ps(Error("No loungeTokenRefreshIntervalMs presents in additionalData: " + JSON.stringify(a) + ".")), a = kSa(b, c)) : a = kSa(b, c)) : a = r8(b);
        return a
    };
    g.k.fL = function(a) {
        var b = this;
        if (!this.isDisposed() && !this.I) {
            u8("New cast session ID: " + a.sessionId);
            var c = a.receiver;
            if (c.receiverType != chrome.cast.ReceiverType.CUSTOM) {
                if (!this.i)
                    if (c.receiverType == chrome.cast.ReceiverType.CAST) u8("Got resumed cast session before resumed mdx connection."), c.friendlyName = chrome.cast.unescape(c.friendlyName), w8(this, new l8(this.l, c, this.config_), !0);
                    else {
                        this.Yd("Got non-cast session without previous mdx receiver event, or mdx resume.");
                        return
                    }
                var d = this.i.i,
                    e = Z6(this.l.Hh(),
                        d.label);
                e && U6(e, c.label) && d.receiverType != chrome.cast.ReceiverType.CAST && c.receiverType == chrome.cast.ReceiverType.CAST && (u8("onSessionEstablished_: manual to cast session change " + c.friendlyName), g.ef(this.i), this.i = new l8(this.l, c, this.config_), this.i.subscribe("sessionScreen", (0, g.D)(this.hL, this, this.i)), this.i.subscribe("sessionFailed", function() {
                    return oSa(b, b.i)
                }), this.i.Vr(null));
                this.i.ME(a)
            }
        }
    };
    g.k.TO = function() {
        return this.i ? this.i.BG() : null
    };
    g.k.CU = function(a) {
        this.isDisposed() || (this.Yd("Failed to estabilish a session: " + g.Jh(a)), a.code != chrome.cast.ErrorCode.CANCEL && w8(this, null), this.Y("yt-remote-cast2-session-failed"))
    };
    g.k.iU = function(a) {
        u8("Receiver availability updated: " + a);
        if (!this.isDisposed()) {
            var b = v8(this);
            this.J = a == chrome.cast.ReceiverAvailability.AVAILABLE;
            v8(this) != b && this.Y("yt-remote-cast2-availability-change", v8(this))
        }
    };
    g.k.CG = function() {
        this.isDisposed() || (this.u = pSa(this), u8("Updating custom receivers: " + g.Jh(this.u)), chrome.cast.setCustomReceivers(this.u, g.Ia, (0, g.D)(function() {
            this.Yd("Failed to set custom receivers.")
        }, this)), this.Y("yt-remote-cast2-availability-change", v8(this)))
    };
    t8.prototype.setLaunchParams = t8.prototype.OV;
    t8.prototype.setConnectedScreenStatus = t8.prototype.NV;
    t8.prototype.stopSession = t8.prototype.UO;
    t8.prototype.getCastSession = t8.prototype.TO;
    t8.prototype.requestSession = t8.prototype.requestSession;
    t8.prototype.init = t8.prototype.init;
    t8.prototype.dispose = t8.prototype.dispose;
    var C8 = [];
    g.k = H8.prototype;
    g.k.reset = function(a) {
        this.listId = "";
        this.index = -1;
        this.videoId = "";
        I8(this);
        this.volume = -1;
        this.muted = !1;
        a && (this.index = a.index, this.listId = a.listId, this.videoId = a.videoId, this.playerState = a.playerState, this.volume = a.volume, this.muted = a.muted, this.audioTrackId = a.audioTrackId, this.trackData = a.trackData, this.xk = a.hasPrevious, this.hasNext = a.hasNext, this.J = a.playerTime, this.I = a.playerTimeAt, this.B = a.seekableStart, this.i = a.seekableEnd, this.C = a.duration, this.L = a.loadedTime, this.u = a.liveIngestionTime, this.l = !isNaN(this.u))
    };
    g.k.xc = function() {
        return 1 == this.playerState
    };
    g.k.isAdPlaying = function() {
        return 1081 == this.playerState
    };
    g.k.Bj = function(a) {
        this.C = isNaN(a) ? 0 : a
    };
    g.k.getDuration = function() {
        return this.l ? this.C + J8(this) : this.C
    };
    g.k.clone = function() {
        return new H8(N8(this))
    };
    g.x(P8, g.R);
    g.k = P8.prototype;
    g.k.getState = function() {
        return this.Qa
    };
    g.k.play = function() {
        R8(this) ? (this.i ? this.i.play(null, g.Ia, W8(this, "play")) : V8(this, "play"), U8(this, 1, L8(Q8(this))), this.Y("remotePlayerChange")) : S8(this, this.play)
    };
    g.k.pause = function() {
        R8(this) ? (this.i ? this.i.pause(null, g.Ia, W8(this, "pause")) : V8(this, "pause"), U8(this, 2, L8(Q8(this))), this.Y("remotePlayerChange")) : S8(this, this.pause)
    };
    g.k.seekTo = function(a) {
        if (R8(this)) {
            if (this.i) {
                var b = Q8(this),
                    c = new chrome.cast.media.SeekRequest;
                c.currentTime = a;
                b.xc() || 3 == b.playerState ? c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_START : c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_PAUSE;
                this.i.seek(c, g.Ia, W8(this, "seekTo", {
                    newTime: a
                }))
            } else V8(this, "seekTo", {
                newTime: a
            });
            U8(this, 3, a);
            this.Y("remotePlayerChange")
        } else S8(this, g.Ra(this.seekTo, a))
    };
    g.k.stop = function() {
        if (R8(this)) {
            this.i ? this.i.stop(null, g.Ia, W8(this, "stopVideo")) : V8(this, "stopVideo");
            var a = Q8(this);
            a.index = -1;
            a.videoId = "";
            I8(a);
            T8(this, a);
            this.Y("remotePlayerChange")
        } else S8(this, this.stop)
    };
    g.k.setVolume = function(a, b) {
        if (R8(this)) {
            var c = Q8(this);
            if (this.l) {
                if (c.volume != a) {
                    var d = Math.round(a) / 100;
                    this.l.setReceiverVolumeLevel(d, (0, g.D)(function() {
                        S7("CP", "set receiver volume: " + d)
                    }, this), (0, g.D)(function() {
                        this.Yd("failed to set receiver volume.")
                    }, this))
                }
                c.muted != b && this.l.setReceiverMuted(b, (0, g.D)(function() {
                    S7("CP", "set receiver muted: " + b)
                }, this), (0, g.D)(function() {
                    this.Yd("failed to set receiver muted.")
                }, this))
            } else {
                var e = {
                    volume: a,
                    muted: b
                }; - 1 != c.volume && (e.delta = a - c.volume);
                V8(this, "setVolume", e)
            }
            c.muted = b;
            c.volume = a;
            T8(this, c)
        } else S8(this, g.Ra(this.setVolume, a, b))
    };
    g.k.DG = function(a, b) {
        if (R8(this)) {
            var c = Q8(this);
            a = {
                videoId: a
            };
            b && (c.trackData = {
                trackName: b.name,
                languageCode: b.languageCode,
                sourceLanguageCode: b.translationLanguage ? b.translationLanguage.languageCode : "",
                languageName: b.languageName,
                kind: b.kind
            }, a.style = g.Jh(b.style), g.cc(a, c.trackData));
            V8(this, "setSubtitlesTrack", a);
            T8(this, c)
        } else S8(this, g.Ra(this.DG, a, b))
    };
    g.k.setAudioTrack = function(a, b) {
        R8(this) ? (b = b.getLanguageInfo().getId(), V8(this, "setAudioTrack", {
            videoId: a,
            audioTrackId: b
        }), a = Q8(this), a.audioTrackId = b, T8(this, a)) : S8(this, g.Ra(this.setAudioTrack, a, b))
    };
    g.k.playVideo = function(a, b, c, d, e, f, h) {
        d = void 0 === d ? null : d;
        e = void 0 === e ? null : e;
        f = void 0 === f ? null : f;
        h = void 0 === h ? null : h;
        var l = Q8(this),
            m = {
                videoId: a
            };
        void 0 !== c && (m.currentIndex = c);
        M8(l, a, c || 0);
        void 0 !== b && (K8(l, b), m.currentTime = b);
        d && (m.listId = d);
        e && (m.playerParams = e);
        f && (m.clickTrackingParams = f);
        h && (m.locationInfo = g.Jh(h));
        V8(this, "setPlaylist", m);
        d || T8(this, l)
    };
    g.k.wz = function(a, b) {
        if (R8(this)) {
            if (a && b) {
                var c = Q8(this);
                M8(c, a, b);
                T8(this, c)
            }
            V8(this, "previous")
        } else S8(this, g.Ra(this.wz, a, b))
    };
    g.k.nextVideo = function(a, b) {
        if (R8(this)) {
            if (a && b) {
                var c = Q8(this);
                M8(c, a, b);
                T8(this, c)
            }
            V8(this, "next")
        } else S8(this, g.Ra(this.nextVideo, a, b))
    };
    g.k.sI = function() {
        R8(this) ? V8(this, "dismissAutoplay") : S8(this, this.sI)
    };
    g.k.dispose = function() {
        if (3 != this.Qa) {
            var a = this.Qa;
            this.Qa = 3;
            this.Y("proxyStateChange", a, this.Qa)
        }
        g.R.prototype.dispose.call(this)
    };
    g.k.va = function() {
        BSa(this);
        this.u = null;
        this.B.clear();
        O8(this, null);
        g.R.prototype.va.call(this)
    };
    g.k.PE = function(a) {
        if ((a != this.Qa || 2 == a) && 3 != this.Qa && 0 != a) {
            var b = this.Qa;
            this.Qa = a;
            this.Y("proxyStateChange", b, a);
            if (1 == a)
                for (; !this.B.isEmpty();) b = a = this.B, 0 === b.i.length && (b.i = b.l, b.i.reverse(), b.l = []), a.i.pop().apply(this);
            else 3 == a && this.dispose()
        }
    };
    g.k.cU = function(a, b) {
        this.Y(a, b)
    };
    g.k.CS = function(a) {
        if (!a) this.Lv(null), O8(this, null);
        else if (this.l.receiver.volume) {
            a = this.l.receiver.volume;
            var b = Q8(this),
                c = Math.round(100 * a.level || 0);
            if (b.volume != c || b.muted != a.muted) S7("CP", "Cast volume update: " + a.level + (a.muted ? " muted" : "")), b.volume = c, b.muted = !!a.muted, T8(this, b)
        }
    };
    g.k.Lv = function(a) {
        S7("CP", "Cast media: " + !!a);
        this.i && this.i.removeUpdateListener(this.J);
        if (this.i = a) this.i.addUpdateListener(this.J), CSa(this), this.Y("remotePlayerChange")
    };
    g.k.BS = function(a) {
        a ? (CSa(this), this.Y("remotePlayerChange")) : this.Lv(null)
    };
    g.k.iF = function() {
        V8(this, "sendDebugCommand", {
            debugCommand: "stats4nerds "
        })
    };
    g.k.KS = function() {
        var a = ySa();
        a && O8(this, a)
    };
    g.k.Yd = function(a) {
        S7("CP", a)
    };
    g.x(X8, g.R);
    g.k = X8.prototype;
    g.k.connect = function(a, b) {
        if (b) {
            var c = b.listId,
                d = b.videoId,
                e = b.videoIds,
                f = b.playerParams,
                h = b.clickTrackingParams,
                l = b.index,
                m = {
                    videoId: d
                },
                n = b.currentTime,
                p = b.locationInfo;
            b = b.loopMode;
            void 0 !== n && (m.currentTime = 5 >= n ? 0 : n);
            f && (m.playerParams = f);
            p && (m.locationInfo = p);
            h && (m.clickTrackingParams = h);
            c && (m.listId = c);
            e && 0 < e.length && (m.videoIds = e.join(","));
            void 0 !== l && (m.currentIndex = l);
            this.Aa && (m.loopMode = b || "LOOP_MODE_OFF");
            c && (this.hc.listId = c);
            this.hc.videoId = d;
            this.hc.index = l || 0;
            this.hc.state = 3;
            K8(this.hc,
                n);
            this.B = "UNSUPPORTED";
            c = this.Aa ? "setInitialState" : "setPlaylist";
            Y8("Connecting with " + c + " and params: " + g.Jh(m));
            this.i.connect({
                method: c,
                params: g.Jh(m)
            }, a, LQa())
        } else Y8("Connecting without params"), this.i.connect({}, a, LQa());
        FSa(this)
    };
    g.k.Oz = function(a) {
        this.i.Oz(a)
    };
    g.k.dispose = function() {
        this.isDisposed() || (g.Ga("yt.mdx.remote.remoteClient_", null, void 0), this.Y("beforeDispose"), Z8(this, 3));
        g.R.prototype.dispose.call(this)
    };
    g.k.va = function() {
        $8(this);
        b9(this);
        a9(this);
        g.jt(this.J);
        this.J = NaN;
        g.jt(this.L);
        this.L = NaN;
        this.u = null;
        g.ou(this.U);
        this.U.length = 0;
        this.i.dispose();
        g.R.prototype.va.call(this);
        this.B = this.I = this.l = this.hc = this.i = null
    };
    g.k.AQ = function() {
        this.wr(2)
    };
    g.k.HS = function() {
        Y8("Channel opened");
        this.xa && (this.xa = !1, a9(this), this.ea = g.ht((0, g.D)(function() {
            Y8("Timing out waiting for a screen.");
            this.wr(1)
        }, this), 15E3));
        PQa(DRa(this.i), this.Ka)
    };
    g.k.DS = function() {
        Y8("Channel closed");
        isNaN(this.C) ? d7(!0) : d7();
        this.dispose()
    };
    g.k.ES = function(a, b) {
        d7();
        isNaN(this.Tu()) ? (b && "shortLived" == this.ya && this.Y("browserChannelAuthError", a), Y8("Channel error: " + a + " without reconnection"), this.dispose()) : (this.xa = !0, Y8("Channel error: " + a + " with reconnection in " + this.Tu() + " ms"), Z8(this, 2))
    };
    g.k.DJ = function(a) {
        if (!this.l || 0 === this.l.length) return !1;
        for (var b = g.r(this.l), c = b.next(); !c.done; c = b.next())
            if (!c.value.capabilities.has(a)) return !1;
        return !0
    };
    g.k.GS = function(a) {
        a.params ? Y8("Received: action=" + a.action + ", params=" + g.Jh(a.params)) : Y8("Received: action=" + a.action + " {}");
        switch (a.action) {
            case "loungeStatus":
                a = Q6(a.params.devices);
                this.l = g.Qe(a, function(c) {
                    return new S6(c)
                });
                a = !!g.gb(this.l, function(c) {
                    return "LOUNGE_SCREEN" == c.type
                });
                ISa(this, a);
                a = this.DJ("mlm");
                this.Y("multiStateLoopEnabled", a);
                break;
            case "loungeScreenDisconnected":
                g.qb(this.l, function(c) {
                    return "LOUNGE_SCREEN" == c.type
                });
                ISa(this, !1);
                break;
            case "remoteConnected":
                var b = new S6(Q6(a.params.device));
                g.gb(this.l, function(c) {
                    return b ? c.id == b.id : !1
                }) || yQa(this.l, b);
                break;
            case "remoteDisconnected":
                b = new S6(Q6(a.params.device));
                g.qb(this.l, function(c) {
                    return b ? c.id == b.id : !1
                });
                break;
            case "gracefulDisconnect":
                break;
            case "playlistModified":
                KSa(this, a);
                break;
            case "nowPlaying":
                MSa(this, a);
                break;
            case "onStateChange":
                LSa(this, a);
                break;
            case "onAdStateChange":
                NSa(this, a);
                break;
            case "onVolumeChanged":
                OSa(this, a);
                break;
            case "onSubtitlesTrackChanged":
                JSa(this, a);
                break;
            case "nowAutoplaying":
                PSa(this, a);
                break;
            case "autoplayDismissed":
                this.Y("autoplayDismissed");
                break;
            case "autoplayUpNext":
                this.I = a.params.videoId || null;
                this.Y("autoplayUpNext", this.I);
                break;
            case "onAutoplayModeChanged":
                this.B =
                    a.params.autoplayMode;
                this.Y("autoplayModeChange", this.B);
                "DISABLED" == this.B && this.Y("autoplayDismissed");
                break;
            case "onHasPreviousNextChanged":
                QSa(this, a);
                break;
            case "requestAssistedSignIn":
                this.Y("assistedSignInRequested", a.params.authCode);
                break;
            case "onLoopModeChanged":
                this.Y("loopModeChange", a.params.loopMode);
                break;
            default:
                Y8("Unrecognized action: " + a.action)
        }
    };
    g.k.CV = function() {
        if (this.u) {
            var a = this.u;
            this.u = null;
            this.hc.videoId != a && c9(this, "getNowPlaying")
        }
    };
    g.k.vQ = function() {
        var a = 3;
        this.isDisposed() || (a = 0, isNaN(this.Tu()) ? N7(this.i) && isNaN(this.C) && (a = 1) : a = 2);
        return a
    };
    g.k.wr = function(a) {
        Y8("Disconnecting with " + a);
        g.Ga("yt.mdx.remote.remoteClient_", null, void 0);
        $8(this);
        this.Y("beforeDisconnect", a);
        1 == a && d7();
        ERa(this.i, a);
        this.dispose()
    };
    g.k.tQ = function() {
        var a = this.hc;
        this.u && (a = this.hc.clone(), M8(a, this.u, a.index));
        return N8(a)
    };
    g.k.PV = function(a) {
        var b = new H8(a);
        b.videoId && b.videoId != this.hc.videoId && (this.u = b.videoId, g.jt(this.J), this.J = g.ht((0, g.D)(this.CV, this), 5E3));
        var c = [];
        this.hc.listId == b.listId && this.hc.videoId == b.videoId && this.hc.index == b.index || c.push("remoteQueueChange");
        this.hc.playerState == b.playerState && this.hc.volume == b.volume && this.hc.muted == b.muted && L8(this.hc) == L8(b) && g.Jh(this.hc.trackData) == g.Jh(b.trackData) || c.push("remotePlayerChange");
        this.hc.reset(a);
        g.Eb(c, function(d) {
            this.Y(d)
        }, this)
    };
    g.k.WI = function() {
        var a = this.i.I.id,
            b = g.gb(this.l, function(c) {
                return "REMOTE_CONTROL" == c.type && c.id != a
            });
        return b ? b.id : ""
    };
    g.k.Tu = function() {
        var a = this.i;
        return a.l.isActive() ? a.l.l - Date.now() : NaN
    };
    g.k.qQ = function() {
        return this.B || "UNSUPPORTED"
    };
    g.k.rQ = function() {
        return this.I || ""
    };
    g.k.VO = function() {
        if (!isNaN(this.Tu())) {
            var a = this.i.l;
            g.Hq(a.i);
            a.start()
        }
    };
    g.k.MV = function(a, b) {
        c9(this, a, b);
        HSa(this)
    };
    g.k.EG = function() {
        var a = g.Ct("SID", "") || "",
            b = g.Ct("SAPISID", "") || "",
            c = g.Ct("__Secure-3PAPISID", "") || "";
        if (!a && !b && !c) return "";
        a = g.ge(g.Za(a), 2);
        b = g.ge(g.Za(b), 2);
        c = g.ge(g.Za(c), 2);
        return g.ge(g.Za(a + "," + b + "," + c), 2)
    };
    X8.prototype.subscribe = X8.prototype.subscribe;
    X8.prototype.unsubscribeByKey = X8.prototype.Uf;
    X8.prototype.getProxyState = X8.prototype.vQ;
    X8.prototype.disconnect = X8.prototype.wr;
    X8.prototype.getPlayerContextData = X8.prototype.tQ;
    X8.prototype.setPlayerContextData = X8.prototype.PV;
    X8.prototype.getOtherConnectedRemoteId = X8.prototype.WI;
    X8.prototype.getReconnectTimeout = X8.prototype.Tu;
    X8.prototype.getAutoplayMode = X8.prototype.qQ;
    X8.prototype.getAutoplayVideoId = X8.prototype.rQ;
    X8.prototype.reconnect = X8.prototype.VO;
    X8.prototype.sendMessage = X8.prototype.MV;
    X8.prototype.getXsrfToken = X8.prototype.EG;
    X8.prototype.isCapabilitySupportedOnConnectedDevices = X8.prototype.DJ;
    g.x(d9, W7);
    g.k = d9.prototype;
    g.k.Hh = function(a) {
        return this.Ne.$_gs(a)
    };
    g.k.contains = function(a) {
        return !!this.Ne.$_c(a)
    };
    g.k.get = function(a) {
        return this.Ne.$_g(a)
    };
    g.k.start = function() {
        this.Ne.$_st()
    };
    g.k.add = function(a, b, c) {
        this.Ne.$_a(a, b, c)
    };
    g.k.remove = function(a, b, c) {
        this.Ne.$_r(a, b, c)
    };
    g.k.jA = function(a, b, c, d) {
        this.Ne.$_un(a, b, c, d)
    };
    g.k.va = function() {
        for (var a = 0, b = this.i.length; a < b; ++a) this.Ne.$_ubk(this.i[a]);
        this.i.length = 0;
        this.Ne = null;
        W7.prototype.va.call(this)
    };
    g.k.WO = function() {
        this.Y("screenChange")
    };
    g.k.GT = function() {
        this.Y("onlineScreenChange")
    };
    f8.prototype.$_st = f8.prototype.start;
    f8.prototype.$_gspc = f8.prototype.QO;
    f8.prototype.$_gsppc = f8.prototype.AG;
    f8.prototype.$_c = f8.prototype.contains;
    f8.prototype.$_g = f8.prototype.get;
    f8.prototype.$_a = f8.prototype.add;
    f8.prototype.$_un = f8.prototype.jA;
    f8.prototype.$_r = f8.prototype.remove;
    f8.prototype.$_gs = f8.prototype.Hh;
    f8.prototype.$_gos = f8.prototype.zG;
    f8.prototype.$_s = f8.prototype.subscribe;
    f8.prototype.$_ubk = f8.prototype.Uf;
    var q9 = null,
        w9 = !1,
        e9 = null,
        f9 = null,
        v9 = null,
        j9 = [];
    g.x(x9, g.G);
    g.k = x9.prototype;
    g.k.va = function() {
        g.G.prototype.va.call(this);
        this.i.stop();
        this.u.stop();
        this.L.stop();
        this.ea();
        var a = this.Qb;
        a.unsubscribe("proxyStateChange", this.dL, this);
        a.unsubscribe("remotePlayerChange", this.Qv, this);
        a.unsubscribe("remoteQueueChange", this.kz, this);
        a.unsubscribe("previousNextChange", this.aL, this);
        a.unsubscribe("nowAutoplaying", this.UK, this);
        a.unsubscribe("autoplayDismissed", this.xK, this);
        this.Qb = this.l = null
    };
    g.k.gj = function(a, b) {
        for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
        if (2 != this.Qb.Qa)
            if (y9(this)) {
                if (!Q8(this.Qb).isAdPlaying() || "control_seek" !== a) switch (a) {
                    case "control_toggle_play_pause":
                        Q8(this.Qb).xc() ? this.Qb.pause() : this.Qb.play();
                        break;
                    case "control_play":
                        this.Qb.play();
                        break;
                    case "control_pause":
                        this.Qb.pause();
                        break;
                    case "control_seek":
                        this.J.yG(c[0], c[1]);
                        break;
                    case "control_subtitles_set_track":
                        z9(this, c[0]);
                        break;
                    case "control_set_audio_track":
                        this.setAudioTrack(c[0])
                }
            } else switch (a) {
                case "control_toggle_play_pause":
                case "control_play":
                case "control_pause":
                    c =
                        this.G.getCurrentTime();
                    A9(this, 0 === c ? void 0 : c);
                    break;
                case "control_seek":
                    A9(this, c[0]);
                    break;
                case "control_subtitles_set_track":
                    z9(this, c[0]);
                    break;
                case "control_set_audio_track":
                    this.setAudioTrack(c[0])
            }
    };
    g.k.zS = function(a) {
        this.L.KO(a)
    };
    g.k.uW = function(a) {
        this.gj("control_subtitles_set_track", g.Vb(a) ? null : a)
    };
    g.k.kM = function() {
        var a = this.G.getOption("captions", "track");
        g.Vb(a) || z9(this, a)
    };
    g.k.Nb = function(a) {
        this.l.Nb(a, this.G.getVideoData().lengthSeconds)
    };
    g.k.qT = function() {
        g.Vb(this.B) || aTa(this, this.B);
        this.C = !1
    };
    g.k.dL = function(a, b) {
        this.u.stop();
        2 === b && this.eM()
    };
    g.k.Qv = function() {
        if (y9(this)) {
            this.i.stop();
            var a = Q8(this.Qb);
            switch (a.playerState) {
                case 1080:
                case 1081:
                case 1084:
                case 1085:
                    this.l.mf = 1;
                    break;
                case 1082:
                case 1083:
                    this.l.mf = 0;
                    break;
                default:
                    this.l.mf = -1
            }
            switch (a.playerState) {
                case 1081:
                case 1:
                    this.Rb(new g.jK(8));
                    this.dM();
                    break;
                case 1085:
                case 3:
                    this.Rb(new g.jK(9));
                    break;
                case 1083:
                case 0:
                    this.Rb(new g.jK(2));
                    this.J.stop();
                    this.Nb(this.G.getVideoData().lengthSeconds);
                    break;
                case 1084:
                    this.Rb(new g.jK(4));
                    break;
                case 2:
                    this.Rb(new g.jK(4));
                    this.Nb(L8(a));
                    break;
                case -1:
                    this.Rb(new g.jK(64));
                    break;
                case -1E3:
                    this.Rb(new g.jK(128, {
                        errorCode: "mdx.remoteerror",
                        errorMessage: "This video is not available for remote playback."
                    }))
            }
            a = Q8(this.Qb).trackData;
            var b = this.B;
            (a || b ? a && b && a.trackName == b.trackName && a.languageCode == b.languageCode && a.languageName == b.languageName && a.kind == b.kind : 1) || (this.B = a, aTa(this, a));
            a = Q8(this.Qb); - 1 === a.volume || Math.round(this.G.getVolume()) === a.volume && this.G.isMuted() === a.muted || this.U.isActive() || this.MM()
        } else $Sa(this)
    };
    g.k.aL = function() {
        this.G.Y("mdxpreviousnextchange")
    };
    g.k.kz = function() {
        y9(this) || $Sa(this)
    };
    g.k.UK = function(a) {
        isNaN(a) || this.G.Y("mdxnowautoplaying", a)
    };
    g.k.xK = function() {
        this.G.Y("mdxautoplaycanceled")
    };
    g.k.setAudioTrack = function(a) {
        y9(this) && this.Qb.setAudioTrack(this.G.getVideoData(1).videoId, a)
    };
    g.k.seekTo = function(a, b) {
        -1 === Q8(this.Qb).playerState ? A9(this, a) : b && this.Qb.seekTo(a)
    };
    g.k.MM = function() {
        var a = this;
        if (y9(this)) {
            var b = Q8(this.Qb);
            this.events.jc(this.Z);
            b.muted ? this.G.mute() : this.G.unMute();
            this.G.setVolume(b.volume);
            this.Z = this.events.N(this.G, "onVolumeChange", function(c) {
                ZSa(a, c)
            })
        }
    };
    g.k.dM = function() {
        this.i.stop();
        if (!this.Qb.isDisposed()) {
            var a = Q8(this.Qb);
            a.xc() && this.Rb(new g.jK(8));
            this.Nb(L8(a));
            this.i.start()
        }
    };
    g.k.eM = function() {
        this.u.stop();
        this.i.stop();
        var a = this.Qb.u.getReconnectTimeout();
        2 == this.Qb.Qa && !isNaN(a) && this.u.start()
    };
    g.k.Rb = function(a) {
        this.u.stop();
        var b = this.I;
        if (!g.oK(b, a)) {
            var c = g.V(a, 2);
            c !== g.V(this.I, 2) && this.G.Is(c);
            this.I = a;
            cTa(this.l, b, a)
        }
    };
    g.x(B9, g.W);
    B9.prototype.bd = function() {
        this.i.show()
    };
    B9.prototype.Bb = function() {
        this.i.hide()
    };
    B9.prototype.l = function() {
        g.RJ("https://support.google.com/youtube/answer/7640706")
    };
    B9.prototype.u = function() {
        R6("mdx-manual-pairing-popup-ok");
        this.Bb()
    };
    g.x(C9, g.W);
    C9.prototype.bd = function() {
        this.i.show()
    };
    C9.prototype.Bb = function() {
        this.i.hide()
    };
    C9.prototype.l = function() {
        R6("mdx-privacy-popup-cancel");
        this.Bb()
    };
    C9.prototype.u = function() {
        R6("mdx-privacy-popup-confirm");
        this.Bb()
    };
    g.x(D9, g.W);
    D9.prototype.l = function(a) {
        bTa(this, a.state)
    };
    g.x(E9, g.eQ);
    E9.prototype.C = function() {
        var a = this.G.getOption("remote", "receivers");
        a && 1 < a.length && !this.G.getOption("remote", "quickCast") ? (this.Rn = g.Fb(a, this.i, this), g.fQ(this, g.Qe(a, this.i)), a = this.G.getOption("remote", "currentReceiver"), a = this.i(a), this.options[a] && this.Vh(a), this.enable(!0)) : this.enable(!1)
    };
    E9.prototype.i = function(a) {
        return a.key
    };
    E9.prototype.Xi = function(a) {
        return "cast-selector-receiver" === a ? "Cast..." : this.Rn[a].name
    };
    E9.prototype.wf = function(a) {
        g.eQ.prototype.wf.call(this, a);
        this.G.setOption("remote", "currentReceiver", this.Rn[a]);
        this.zb.Bb()
    };
    g.x(F9, g.oN);
    g.k = F9.prototype;
    g.k.create = function() {
        var a = this.player.T(),
            b = g.xF(a);
        a = {
            device: "Desktop",
            app: "youtube-desktop",
            loadCastApiSetupScript: g.T(a.experiments, "mdx_load_cast_api_bootstrap_script"),
            enableDialLoungeToken: g.T(a.experiments, "enable_dial_short_lived_lounge_token"),
            enableCastLoungeToken: g.T(a.experiments, "enable_cast_short_lived_lounge_token")
        };
        USa(b, a);
        this.subscriptions.push(g.Wu("yt-remote-before-disconnect", this.yS, this));
        this.subscriptions.push(g.Wu("yt-remote-connection-change", this.jU, this));
        this.subscriptions.push(g.Wu("yt-remote-receiver-availability-change",
            this.cL, this));
        this.subscriptions.push(g.Wu("yt-remote-auto-connect", this.hU, this));
        this.subscriptions.push(g.Wu("yt-remote-receiver-resumed", this.gU, this));
        this.subscriptions.push(g.Wu("mdx-privacy-popup-confirm", this.sV, this));
        this.subscriptions.push(g.Wu("mdx-privacy-popup-cancel", this.rV, this));
        this.subscriptions.push(g.Wu("mdx-manual-pairing-popup-ok", this.CR, this));
        this.cL()
    };
    g.k.load = function() {
        this.player.cancelPlayback();
        g.oN.prototype.load.call(this);
        this.yh = new x9(this, this.player, this.Qb);
        var a = (a = YSa()) ? a.currentTime : 0;
        var b = u9() ? new P8(o9(), void 0) : null;
        0 == a && b && (a = L8(Q8(b)));
        0 !== a && this.Nb(a);
        cTa(this, this.od, this.od);
        this.player.Mk(6)
    };
    g.k.unload = function() {
        this.player.Y("mdxautoplaycanceled");
        this.Mm = this.mj;
        g.ff(this.yh, this.Qb);
        this.Qb = this.yh = null;
        g.oN.prototype.unload.call(this);
        this.player.Mk(5);
        G9(this)
    };
    g.k.va = function() {
        g.Xu(this.subscriptions);
        g.oN.prototype.va.call(this)
    };
    g.k.Fk = function(a, b) {
        for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
        this.loaded && this.yh.gj.apply(this.yh, [a].concat(g.v(c)))
    };
    g.k.getAdState = function() {
        return this.mf
    };
    g.k.wQ = function() {
        return this.loaded ? this.yh.suggestion : null
    };
    g.k.xk = function() {
        return this.Qb ? Q8(this.Qb).xk : !1
    };
    g.k.hasNext = function() {
        return this.Qb ? Q8(this.Qb).hasNext : !1
    };
    g.k.Nb = function(a, b) {
        this.QJ = a || 0;
        this.player.Y("progresssync", a, b);
        this.player.Na("onVideoProgress", a)
    };
    g.k.getCurrentTime = function() {
        return this.QJ
    };
    g.k.getProgressState = function() {
        var a = Q8(this.Qb),
            b = this.player.getVideoData();
        return {
            airingStart: 0,
            airingEnd: 0,
            allowSeeking: g.T(this.player.T().experiments, "web_player_mdx_allow_seeking_change_killswitch") ? this.player.kf() : !a.isAdPlaying() && this.player.kf(),
            clipEnd: b.clipEnd,
            clipStart: b.clipStart,
            current: this.getCurrentTime(),
            displayedStart: -1,
            duration: a.getDuration(),
            ingestionTime: a.l ? a.u + J8(a) : a.u,
            isAtLiveHead: 1 >= (a.l ? a.i + J8(a) : a.i) - this.getCurrentTime(),
            loaded: a.L,
            seekableEnd: a.l ? a.i + J8(a) : a.i,
            seekableStart: 0 < a.B ? a.B + J8(a) : a.B
        }
    };
    g.k.nextVideo = function() {
        this.Qb && this.Qb.nextVideo()
    };
    g.k.wz = function() {
        this.Qb && this.Qb.wz()
    };
    g.k.yS = function(a) {
        1 === a && (this.pE = this.Qb ? Q8(this.Qb) : null)
    };
    g.k.jU = function() {
        var a = u9() ? new P8(o9(), void 0) : null;
        if (a) {
            var b = this.Mm;
            this.loaded && this.unload();
            this.Qb = a;
            this.pE = null;
            b.key !== this.mj.key && (this.Mm = b, this.load())
        } else g.ef(this.Qb), this.Qb = null, this.loaded && (this.unload(), (a = this.pE) && a.videoId === this.player.getVideoData().videoId && this.player.cueVideoById(a.videoId, L8(a)));
        this.player.Y("videodatachange", "newdata", this.player.getVideoData(), 3)
    };
    g.k.cL = function() {
        var a = [this.mj],
            b = a.concat,
            c = VSa();
        D8() && g.zz("yt-remote-cast-available") && c.push({
            key: "cast-selector-receiver",
            name: "Cast..."
        });
        this.Rn = b.call(a, c);
        a = p9() || this.mj;
        H9(this, a);
        this.player.Na("onMdxReceiversChange")
    };
    g.k.hU = function() {
        var a = p9();
        H9(this, a)
    };
    g.k.gU = function() {
        this.Mm = p9()
    };
    g.k.sV = function() {
        this.Uv = !0;
        G9(this);
        w9 = !1;
        q9 && s9(q9, 1);
        q9 = null
    };
    g.k.rV = function() {
        this.Uv = !1;
        G9(this);
        H9(this, this.mj);
        this.Mm = this.mj;
        w9 = !1;
        q9 = null;
        this.player.playVideo()
    };
    g.k.CR = function() {
        this.Jy = !0;
        G9(this);
        g.yz("yt-remote-manual-pairing-warning-shown", !0, 2592E3);
        w9 = !1;
        q9 && s9(q9, 1);
        q9 = null
    };
    g.k.bf = function(a, b) {
        switch (a) {
            case "casting":
                return this.loaded;
            case "receivers":
                return this.Rn;
            case "currentReceiver":
                return b && ("cast-selector-receiver" === b.key ? F8() : H9(this, b)), this.loaded ? this.Mm : this.mj;
            case "quickCast":
                return 2 === this.Rn.length && "cast-selector-receiver" === this.Rn[1].key ? (b && F8(), !0) : !1
        }
    };
    g.k.iF = function() {
        this.Qb.iF()
    };
    g.k.Ii = function() {
        return !1
    };
    g.k.getOptions = function() {
        return ["casting", "receivers", "currentReceiver", "quickCast"]
    };
    g.zN.remote = F9;
})(_yt_player);